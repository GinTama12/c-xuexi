﻿namespace ClientGobang
{
    partial class Frm_Hall
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Frm_Hall));
            System.Windows.Forms.TreeNode treeNode123 = new System.Windows.Forms.TreeNode("房间1");
            System.Windows.Forms.TreeNode treeNode124 = new System.Windows.Forms.TreeNode("房间2");
            System.Windows.Forms.TreeNode treeNode125 = new System.Windows.Forms.TreeNode("房间3");
            System.Windows.Forms.TreeNode treeNode126 = new System.Windows.Forms.TreeNode("房间4");
            System.Windows.Forms.TreeNode treeNode127 = new System.Windows.Forms.TreeNode("房间5");
            System.Windows.Forms.TreeNode treeNode128 = new System.Windows.Forms.TreeNode("房间6");
            System.Windows.Forms.TreeNode treeNode129 = new System.Windows.Forms.TreeNode("房间7");
            System.Windows.Forms.TreeNode treeNode130 = new System.Windows.Forms.TreeNode("房间8");
            System.Windows.Forms.TreeNode treeNode131 = new System.Windows.Forms.TreeNode("房间9");
            System.Windows.Forms.TreeNode treeNode132 = new System.Windows.Forms.TreeNode("普通区一", new System.Windows.Forms.TreeNode[] {
            treeNode123,
            treeNode124,
            treeNode125,
            treeNode126,
            treeNode127,
            treeNode128,
            treeNode129,
            treeNode130,
            treeNode131});
            System.Windows.Forms.TreeNode treeNode133 = new System.Windows.Forms.TreeNode("房间1");
            System.Windows.Forms.TreeNode treeNode134 = new System.Windows.Forms.TreeNode("房间2");
            System.Windows.Forms.TreeNode treeNode135 = new System.Windows.Forms.TreeNode("房间3");
            System.Windows.Forms.TreeNode treeNode136 = new System.Windows.Forms.TreeNode("房间4");
            System.Windows.Forms.TreeNode treeNode137 = new System.Windows.Forms.TreeNode("房间5");
            System.Windows.Forms.TreeNode treeNode138 = new System.Windows.Forms.TreeNode("房间6");
            System.Windows.Forms.TreeNode treeNode139 = new System.Windows.Forms.TreeNode("房间7");
            System.Windows.Forms.TreeNode treeNode140 = new System.Windows.Forms.TreeNode("房间8");
            System.Windows.Forms.TreeNode treeNode141 = new System.Windows.Forms.TreeNode("房间9");
            System.Windows.Forms.TreeNode treeNode142 = new System.Windows.Forms.TreeNode("普通区二", new System.Windows.Forms.TreeNode[] {
            treeNode133,
            treeNode134,
            treeNode135,
            treeNode136,
            treeNode137,
            treeNode138,
            treeNode139,
            treeNode140,
            treeNode141});
            System.Windows.Forms.TreeNode treeNode143 = new System.Windows.Forms.TreeNode("房间1");
            System.Windows.Forms.TreeNode treeNode144 = new System.Windows.Forms.TreeNode("房间2");
            System.Windows.Forms.TreeNode treeNode145 = new System.Windows.Forms.TreeNode("房间3");
            System.Windows.Forms.TreeNode treeNode146 = new System.Windows.Forms.TreeNode("房间4");
            System.Windows.Forms.TreeNode treeNode147 = new System.Windows.Forms.TreeNode("房间5");
            System.Windows.Forms.TreeNode treeNode148 = new System.Windows.Forms.TreeNode("房间6");
            System.Windows.Forms.TreeNode treeNode149 = new System.Windows.Forms.TreeNode("房间7");
            System.Windows.Forms.TreeNode treeNode150 = new System.Windows.Forms.TreeNode("房间8");
            System.Windows.Forms.TreeNode treeNode151 = new System.Windows.Forms.TreeNode("房间9");
            System.Windows.Forms.TreeNode treeNode152 = new System.Windows.Forms.TreeNode("普通区三", new System.Windows.Forms.TreeNode[] {
            treeNode143,
            treeNode144,
            treeNode145,
            treeNode146,
            treeNode147,
            treeNode148,
            treeNode149,
            treeNode150,
            treeNode151});
            System.Windows.Forms.TreeNode treeNode153 = new System.Windows.Forms.TreeNode("房间1");
            System.Windows.Forms.TreeNode treeNode154 = new System.Windows.Forms.TreeNode("房间2");
            System.Windows.Forms.TreeNode treeNode155 = new System.Windows.Forms.TreeNode("房间3");
            System.Windows.Forms.TreeNode treeNode156 = new System.Windows.Forms.TreeNode("房间4");
            System.Windows.Forms.TreeNode treeNode157 = new System.Windows.Forms.TreeNode("房间5");
            System.Windows.Forms.TreeNode treeNode158 = new System.Windows.Forms.TreeNode("房间6");
            System.Windows.Forms.TreeNode treeNode159 = new System.Windows.Forms.TreeNode("房间7");
            System.Windows.Forms.TreeNode treeNode160 = new System.Windows.Forms.TreeNode("房间8");
            System.Windows.Forms.TreeNode treeNode161 = new System.Windows.Forms.TreeNode("房间9");
            System.Windows.Forms.TreeNode treeNode162 = new System.Windows.Forms.TreeNode("高手区一", new System.Windows.Forms.TreeNode[] {
            treeNode153,
            treeNode154,
            treeNode155,
            treeNode156,
            treeNode157,
            treeNode158,
            treeNode159,
            treeNode160,
            treeNode161});
            System.Windows.Forms.TreeNode treeNode163 = new System.Windows.Forms.TreeNode("房间1");
            System.Windows.Forms.TreeNode treeNode164 = new System.Windows.Forms.TreeNode("房间2");
            System.Windows.Forms.TreeNode treeNode165 = new System.Windows.Forms.TreeNode("房间3");
            System.Windows.Forms.TreeNode treeNode166 = new System.Windows.Forms.TreeNode("房间4");
            System.Windows.Forms.TreeNode treeNode167 = new System.Windows.Forms.TreeNode("房间5");
            System.Windows.Forms.TreeNode treeNode168 = new System.Windows.Forms.TreeNode("房间6");
            System.Windows.Forms.TreeNode treeNode169 = new System.Windows.Forms.TreeNode("房间7");
            System.Windows.Forms.TreeNode treeNode170 = new System.Windows.Forms.TreeNode("房间8");
            System.Windows.Forms.TreeNode treeNode171 = new System.Windows.Forms.TreeNode("房间9");
            System.Windows.Forms.TreeNode treeNode172 = new System.Windows.Forms.TreeNode("高手区二", new System.Windows.Forms.TreeNode[] {
            treeNode163,
            treeNode164,
            treeNode165,
            treeNode166,
            treeNode167,
            treeNode168,
            treeNode169,
            treeNode170,
            treeNode171});
            System.Windows.Forms.TreeNode treeNode173 = new System.Windows.Forms.TreeNode("房间1");
            System.Windows.Forms.TreeNode treeNode174 = new System.Windows.Forms.TreeNode("房间2");
            System.Windows.Forms.TreeNode treeNode175 = new System.Windows.Forms.TreeNode("房间3");
            System.Windows.Forms.TreeNode treeNode176 = new System.Windows.Forms.TreeNode("房间4");
            System.Windows.Forms.TreeNode treeNode177 = new System.Windows.Forms.TreeNode("房间5");
            System.Windows.Forms.TreeNode treeNode178 = new System.Windows.Forms.TreeNode("房间6");
            System.Windows.Forms.TreeNode treeNode179 = new System.Windows.Forms.TreeNode("房间7");
            System.Windows.Forms.TreeNode treeNode180 = new System.Windows.Forms.TreeNode("房间8");
            System.Windows.Forms.TreeNode treeNode181 = new System.Windows.Forms.TreeNode("房间9");
            System.Windows.Forms.TreeNode treeNode182 = new System.Windows.Forms.TreeNode("高手区三", new System.Windows.Forms.TreeNode[] {
            treeNode173,
            treeNode174,
            treeNode175,
            treeNode176,
            treeNode177,
            treeNode178,
            treeNode179,
            treeNode180,
            treeNode181});
            System.Windows.Forms.TreeNode treeNode183 = new System.Windows.Forms.TreeNode("五子棋", new System.Windows.Forms.TreeNode[] {
            treeNode132,
            treeNode142,
            treeNode152,
            treeNode162,
            treeNode172,
            treeNode182});
            this.panel_Title = new System.Windows.Forms.Panel();
            this.Image_Max = new System.Windows.Forms.PictureBox();
            this.Image_Close = new System.Windows.Forms.PictureBox();
            this.Image_Min = new System.Windows.Forms.PictureBox();
            this.panel_BorderL = new System.Windows.Forms.Panel();
            this.panel_BorderR = new System.Windows.Forms.Panel();
            this.panel_BorderT = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel_Tree = new System.Windows.Forms.Panel();
            this.treeView_Area = new System.Windows.Forms.TreeView();
            this.panel_TreeT = new System.Windows.Forms.Panel();
            this.panel_LAmong = new System.Windows.Forms.Panel();
            this.pictureBox_LA = new System.Windows.Forms.PictureBox();
            this.panel_Public = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.RTB_Dialog = new System.Windows.Forms.RichTextBox();
            this.panel_DialogB = new System.Windows.Forms.Panel();
            this.pictureBox_Hair = new System.Windows.Forms.PictureBox();
            this.comboBox_Hair = new System.Windows.Forms.ComboBox();
            this.panel_DialogTit = new System.Windows.Forms.Panel();
            this.listView_user = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.panel_PerTit = new System.Windows.Forms.Panel();
            this.pictureBox65 = new System.Windows.Forms.PictureBox();
            this.pictureBox64 = new System.Windows.Forms.PictureBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.imageList2 = new System.Windows.Forms.ImageList(this.components);
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.panel_RA = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel_OpposeTit = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pictureBox_Back = new System.Windows.Forms.PictureBox();
            this.flowPanel_Oppose = new System.Windows.Forms.FlowLayoutPanel();
            this.Desk_01 = new System.Windows.Forms.Panel();
            this.label1_2 = new System.Windows.Forms.Label();
            this.label2_1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.Desk_02 = new System.Windows.Forms.Panel();
            this.label4_2 = new System.Windows.Forms.Label();
            this.label5_1 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.Desk_03 = new System.Windows.Forms.Panel();
            this.label7_2 = new System.Windows.Forms.Label();
            this.label8_1 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.Desk_04 = new System.Windows.Forms.Panel();
            this.label10_2 = new System.Windows.Forms.Label();
            this.label11_1 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.Desk_05 = new System.Windows.Forms.Panel();
            this.label16_2 = new System.Windows.Forms.Label();
            this.label17_1 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.pictureBox17 = new System.Windows.Forms.PictureBox();
            this.pictureBox18 = new System.Windows.Forms.PictureBox();
            this.pictureBox19 = new System.Windows.Forms.PictureBox();
            this.Desk_06 = new System.Windows.Forms.Panel();
            this.label13_2 = new System.Windows.Forms.Label();
            this.label14_1 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.pictureBox14 = new System.Windows.Forms.PictureBox();
            this.pictureBox15 = new System.Windows.Forms.PictureBox();
            this.pictureBox16 = new System.Windows.Forms.PictureBox();
            this.Desk_07 = new System.Windows.Forms.Panel();
            this.label19_2 = new System.Windows.Forms.Label();
            this.label20_1 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.pictureBox20 = new System.Windows.Forms.PictureBox();
            this.pictureBox21 = new System.Windows.Forms.PictureBox();
            this.pictureBox22 = new System.Windows.Forms.PictureBox();
            this.Desk_08 = new System.Windows.Forms.Panel();
            this.label22_2 = new System.Windows.Forms.Label();
            this.label23_1 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.pictureBox23 = new System.Windows.Forms.PictureBox();
            this.pictureBox24 = new System.Windows.Forms.PictureBox();
            this.pictureBox25 = new System.Windows.Forms.PictureBox();
            this.Desk_09 = new System.Windows.Forms.Panel();
            this.label25_2 = new System.Windows.Forms.Label();
            this.label26_1 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.pictureBox26 = new System.Windows.Forms.PictureBox();
            this.pictureBox27 = new System.Windows.Forms.PictureBox();
            this.pictureBox28 = new System.Windows.Forms.PictureBox();
            this.Desk_10 = new System.Windows.Forms.Panel();
            this.label28_2 = new System.Windows.Forms.Label();
            this.label29_1 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.pictureBox29 = new System.Windows.Forms.PictureBox();
            this.pictureBox30 = new System.Windows.Forms.PictureBox();
            this.pictureBox31 = new System.Windows.Forms.PictureBox();
            this.Desk_11 = new System.Windows.Forms.Panel();
            this.label31_2 = new System.Windows.Forms.Label();
            this.label32_1 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.pictureBox32 = new System.Windows.Forms.PictureBox();
            this.pictureBox33 = new System.Windows.Forms.PictureBox();
            this.pictureBox34 = new System.Windows.Forms.PictureBox();
            this.Desk_12 = new System.Windows.Forms.Panel();
            this.label34_2 = new System.Windows.Forms.Label();
            this.label35_1 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.pictureBox35 = new System.Windows.Forms.PictureBox();
            this.pictureBox36 = new System.Windows.Forms.PictureBox();
            this.pictureBox37 = new System.Windows.Forms.PictureBox();
            this.Desk_13 = new System.Windows.Forms.Panel();
            this.label37_2 = new System.Windows.Forms.Label();
            this.label38_1 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.pictureBox38 = new System.Windows.Forms.PictureBox();
            this.pictureBox39 = new System.Windows.Forms.PictureBox();
            this.pictureBox40 = new System.Windows.Forms.PictureBox();
            this.Desk_14 = new System.Windows.Forms.Panel();
            this.label40_2 = new System.Windows.Forms.Label();
            this.label41_1 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.pictureBox41 = new System.Windows.Forms.PictureBox();
            this.pictureBox42 = new System.Windows.Forms.PictureBox();
            this.pictureBox43 = new System.Windows.Forms.PictureBox();
            this.Desk_15 = new System.Windows.Forms.Panel();
            this.label43_2 = new System.Windows.Forms.Label();
            this.label44_1 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.pictureBox44 = new System.Windows.Forms.PictureBox();
            this.pictureBox45 = new System.Windows.Forms.PictureBox();
            this.pictureBox46 = new System.Windows.Forms.PictureBox();
            this.Desk_16 = new System.Windows.Forms.Panel();
            this.label46_2 = new System.Windows.Forms.Label();
            this.label47_1 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.pictureBox47 = new System.Windows.Forms.PictureBox();
            this.pictureBox48 = new System.Windows.Forms.PictureBox();
            this.pictureBox49 = new System.Windows.Forms.PictureBox();
            this.Desk_17 = new System.Windows.Forms.Panel();
            this.label49_2 = new System.Windows.Forms.Label();
            this.label50_1 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.pictureBox50 = new System.Windows.Forms.PictureBox();
            this.pictureBox51 = new System.Windows.Forms.PictureBox();
            this.pictureBox52 = new System.Windows.Forms.PictureBox();
            this.Desk_18 = new System.Windows.Forms.Panel();
            this.label52_2 = new System.Windows.Forms.Label();
            this.label53_1 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.pictureBox53 = new System.Windows.Forms.PictureBox();
            this.pictureBox54 = new System.Windows.Forms.PictureBox();
            this.pictureBox55 = new System.Windows.Forms.PictureBox();
            this.Desk_19 = new System.Windows.Forms.Panel();
            this.label55_2 = new System.Windows.Forms.Label();
            this.label56_1 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.pictureBox56 = new System.Windows.Forms.PictureBox();
            this.pictureBox57 = new System.Windows.Forms.PictureBox();
            this.pictureBox58 = new System.Windows.Forms.PictureBox();
            this.Desk_20 = new System.Windows.Forms.Panel();
            this.label58_2 = new System.Windows.Forms.Label();
            this.label59_1 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.pictureBox59 = new System.Windows.Forms.PictureBox();
            this.pictureBox60 = new System.Windows.Forms.PictureBox();
            this.pictureBox61 = new System.Windows.Forms.PictureBox();
            this.udpSocket1 = new GobangClass.UDPSocket(this.components);
            this.pictureBox63 = new System.Windows.Forms.PictureBox();
            this.panel_Cover = new System.Windows.Forms.Panel();
            this.panel_Title.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Image_Max)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Image_Close)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Image_Min)).BeginInit();
            this.panel_Tree.SuspendLayout();
            this.panel_LAmong.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_LA)).BeginInit();
            this.panel_Public.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel_DialogB.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Hair)).BeginInit();
            this.panel_PerTit.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox65)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox64)).BeginInit();
            this.panel_RA.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Back)).BeginInit();
            this.flowPanel_Oppose.SuspendLayout();
            this.Desk_01.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.Desk_02.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            this.Desk_03.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            this.Desk_04.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            this.Desk_05.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).BeginInit();
            this.Desk_06.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).BeginInit();
            this.Desk_07.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox22)).BeginInit();
            this.Desk_08.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox25)).BeginInit();
            this.Desk_09.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox26)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox27)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox28)).BeginInit();
            this.Desk_10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox29)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox30)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox31)).BeginInit();
            this.Desk_11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox32)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox33)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox34)).BeginInit();
            this.Desk_12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox35)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox36)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox37)).BeginInit();
            this.Desk_13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox38)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox39)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox40)).BeginInit();
            this.Desk_14.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox41)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox42)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox43)).BeginInit();
            this.Desk_15.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox44)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox45)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox46)).BeginInit();
            this.Desk_16.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox47)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox48)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox49)).BeginInit();
            this.Desk_17.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox50)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox51)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox52)).BeginInit();
            this.Desk_18.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox53)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox54)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox55)).BeginInit();
            this.Desk_19.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox56)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox57)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox58)).BeginInit();
            this.Desk_20.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox59)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox60)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox61)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox63)).BeginInit();
            this.panel_Cover.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel_Title
            // 
            this.panel_Title.BackColor = System.Drawing.Color.Transparent;
            this.panel_Title.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel_Title.BackgroundImage")));
            this.panel_Title.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel_Title.Controls.Add(this.Image_Max);
            this.panel_Title.Controls.Add(this.Image_Close);
            this.panel_Title.Controls.Add(this.Image_Min);
            this.panel_Title.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_Title.Location = new System.Drawing.Point(0, 0);
            this.panel_Title.Name = "panel_Title";
            this.panel_Title.Size = new System.Drawing.Size(927, 27);
            this.panel_Title.TabIndex = 0;
            this.panel_Title.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel_Title_MouseDown);
            this.panel_Title.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel_Title_MouseMove);
            // 
            // Image_Max
            // 
            this.Image_Max.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Image_Max.BackColor = System.Drawing.SystemColors.Info;
            this.Image_Max.Image = ((System.Drawing.Image)(resources.GetObject("Image_Max.Image")));
            this.Image_Max.Location = new System.Drawing.Point(870, 4);
            this.Image_Max.Name = "Image_Max";
            this.Image_Max.Size = new System.Drawing.Size(20, 20);
            this.Image_Max.TabIndex = 2;
            this.Image_Max.TabStop = false;
            this.Image_Max.Tag = "2";
            this.Image_Max.Click += new System.EventHandler(this.Image_Max_Click);
            this.Image_Max.MouseEnter += new System.EventHandler(this.Image_Min_MouseEnter);
            this.Image_Max.MouseLeave += new System.EventHandler(this.Image_Min_MouseLeave);
            // 
            // Image_Close
            // 
            this.Image_Close.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Image_Close.BackColor = System.Drawing.SystemColors.Info;
            this.Image_Close.Image = ((System.Drawing.Image)(resources.GetObject("Image_Close.Image")));
            this.Image_Close.Location = new System.Drawing.Point(897, 4);
            this.Image_Close.Name = "Image_Close";
            this.Image_Close.Size = new System.Drawing.Size(20, 20);
            this.Image_Close.TabIndex = 1;
            this.Image_Close.TabStop = false;
            this.Image_Close.Tag = "3";
            this.Image_Close.Click += new System.EventHandler(this.Image_Close_Click);
            this.Image_Close.MouseEnter += new System.EventHandler(this.Image_Min_MouseEnter);
            this.Image_Close.MouseLeave += new System.EventHandler(this.Image_Min_MouseLeave);
            // 
            // Image_Min
            // 
            this.Image_Min.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Image_Min.BackColor = System.Drawing.SystemColors.Info;
            this.Image_Min.Image = ((System.Drawing.Image)(resources.GetObject("Image_Min.Image")));
            this.Image_Min.Location = new System.Drawing.Point(843, 4);
            this.Image_Min.Name = "Image_Min";
            this.Image_Min.Size = new System.Drawing.Size(20, 20);
            this.Image_Min.TabIndex = 0;
            this.Image_Min.TabStop = false;
            this.Image_Min.Tag = "1";
            this.Image_Min.Click += new System.EventHandler(this.Image_Min_Click);
            this.Image_Min.MouseEnter += new System.EventHandler(this.Image_Min_MouseEnter);
            this.Image_Min.MouseLeave += new System.EventHandler(this.Image_Min_MouseLeave);
            // 
            // panel_BorderL
            // 
            this.panel_BorderL.BackColor = System.Drawing.SystemColors.HotTrack;
            this.panel_BorderL.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel_BorderL.BackgroundImage")));
            this.panel_BorderL.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel_BorderL.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel_BorderL.Location = new System.Drawing.Point(0, 27);
            this.panel_BorderL.Name = "panel_BorderL";
            this.panel_BorderL.Size = new System.Drawing.Size(3, 558);
            this.panel_BorderL.TabIndex = 1;
            // 
            // panel_BorderR
            // 
            this.panel_BorderR.BackColor = System.Drawing.SystemColors.HotTrack;
            this.panel_BorderR.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel_BorderR.BackgroundImage")));
            this.panel_BorderR.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel_BorderR.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel_BorderR.Location = new System.Drawing.Point(924, 27);
            this.panel_BorderR.Name = "panel_BorderR";
            this.panel_BorderR.Size = new System.Drawing.Size(3, 558);
            this.panel_BorderR.TabIndex = 2;
            // 
            // panel_BorderT
            // 
            this.panel_BorderT.BackColor = System.Drawing.SystemColors.HotTrack;
            this.panel_BorderT.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel_BorderT.BackgroundImage")));
            this.panel_BorderT.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel_BorderT.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_BorderT.Location = new System.Drawing.Point(3, 96);
            this.panel_BorderT.Name = "panel_BorderT";
            this.panel_BorderT.Size = new System.Drawing.Size(921, 3);
            this.panel_BorderT.TabIndex = 4;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.HotTrack;
            this.panel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel1.BackgroundImage")));
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(3, 564);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(921, 21);
            this.panel1.TabIndex = 5;
            // 
            // panel_Tree
            // 
            this.panel_Tree.Controls.Add(this.treeView_Area);
            this.panel_Tree.Controls.Add(this.panel_TreeT);
            this.panel_Tree.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel_Tree.Location = new System.Drawing.Point(3, 99);
            this.panel_Tree.Name = "panel_Tree";
            this.panel_Tree.Size = new System.Drawing.Size(200, 465);
            this.panel_Tree.TabIndex = 6;
            // 
            // treeView_Area
            // 
            this.treeView_Area.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.treeView_Area.Dock = System.Windows.Forms.DockStyle.Fill;
            this.treeView_Area.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.treeView_Area.ForeColor = System.Drawing.SystemColors.Desktop;
            this.treeView_Area.HideSelection = false;
            this.treeView_Area.Indent = 25;
            this.treeView_Area.ItemHeight = 25;
            this.treeView_Area.Location = new System.Drawing.Point(0, 26);
            this.treeView_Area.Name = "treeView_Area";
            treeNode123.Name = "Room_1";
            treeNode123.Tag = "1";
            treeNode123.Text = "房间1";
            treeNode124.Name = "Room_2";
            treeNode124.Tag = "2";
            treeNode124.Text = "房间2";
            treeNode125.Name = "Room_3";
            treeNode125.Tag = "3";
            treeNode125.Text = "房间3";
            treeNode126.Name = "Room_4";
            treeNode126.Tag = "4";
            treeNode126.Text = "房间4";
            treeNode127.Name = "Room_5";
            treeNode127.Tag = "5";
            treeNode127.Text = "房间5";
            treeNode128.Name = "Room_6";
            treeNode128.Tag = "6";
            treeNode128.Text = "房间6";
            treeNode129.Name = "Room_7";
            treeNode129.Tag = "7";
            treeNode129.Text = "房间7";
            treeNode130.Name = "Room_8";
            treeNode130.Tag = "8";
            treeNode130.Text = "房间8";
            treeNode131.Name = "Room_9";
            treeNode131.Tag = "9";
            treeNode131.Text = "房间9";
            treeNode132.Checked = true;
            treeNode132.Name = "TreeAreaMark_1";
            treeNode132.Tag = "1";
            treeNode132.Text = "普通区一";
            treeNode133.Name = "Room_1";
            treeNode133.Tag = "1";
            treeNode133.Text = "房间1";
            treeNode134.Name = "Room_2";
            treeNode134.Tag = "2";
            treeNode134.Text = "房间2";
            treeNode135.Name = "Room_3";
            treeNode135.Tag = "3";
            treeNode135.Text = "房间3";
            treeNode136.Name = "Room_4";
            treeNode136.Tag = "4";
            treeNode136.Text = "房间4";
            treeNode137.Name = "Room_5";
            treeNode137.Tag = "5";
            treeNode137.Text = "房间5";
            treeNode138.Name = "Room_6";
            treeNode138.Tag = "6";
            treeNode138.Text = "房间6";
            treeNode139.Name = "Room_7";
            treeNode139.Tag = "7";
            treeNode139.Text = "房间7";
            treeNode140.Name = "Room_8";
            treeNode140.Tag = "8";
            treeNode140.Text = "房间8";
            treeNode141.Name = "Room_9";
            treeNode141.Tag = "9";
            treeNode141.Text = "房间9";
            treeNode142.Name = "TreeAreaMark_2";
            treeNode142.Tag = "2";
            treeNode142.Text = "普通区二";
            treeNode143.Name = "Room_1";
            treeNode143.Tag = "1";
            treeNode143.Text = "房间1";
            treeNode144.Name = "Room_2";
            treeNode144.Tag = "2";
            treeNode144.Text = "房间2";
            treeNode145.Name = "Room_3";
            treeNode145.Tag = "3";
            treeNode145.Text = "房间3";
            treeNode146.Name = "Room_4";
            treeNode146.Tag = "4";
            treeNode146.Text = "房间4";
            treeNode147.Name = "Room_5";
            treeNode147.Tag = "5";
            treeNode147.Text = "房间5";
            treeNode148.Name = "Room_6";
            treeNode148.Tag = "6";
            treeNode148.Text = "房间6";
            treeNode149.Name = "Room_7";
            treeNode149.Tag = "7";
            treeNode149.Text = "房间7";
            treeNode150.Name = "Room_8";
            treeNode150.Tag = "8";
            treeNode150.Text = "房间8";
            treeNode151.Name = "Room_9";
            treeNode151.Tag = "9";
            treeNode151.Text = "房间9";
            treeNode152.Name = "TreeAreaMark_3";
            treeNode152.Tag = "3";
            treeNode152.Text = "普通区三";
            treeNode153.Name = "Room_1";
            treeNode153.Tag = "1";
            treeNode153.Text = "房间1";
            treeNode154.Name = "Room_2";
            treeNode154.Tag = "2";
            treeNode154.Text = "房间2";
            treeNode155.Name = "Room_3";
            treeNode155.Tag = "3";
            treeNode155.Text = "房间3";
            treeNode156.Name = "Room_4";
            treeNode156.Tag = "4";
            treeNode156.Text = "房间4";
            treeNode157.Name = "Room_5";
            treeNode157.Tag = "5";
            treeNode157.Text = "房间5";
            treeNode158.Name = "Room_6";
            treeNode158.Tag = "6";
            treeNode158.Text = "房间6";
            treeNode159.Name = "Room_7";
            treeNode159.Tag = "7";
            treeNode159.Text = "房间7";
            treeNode160.Name = "Room_8";
            treeNode160.Tag = "8";
            treeNode160.Text = "房间8";
            treeNode161.Name = "Room_9";
            treeNode161.Tag = "9";
            treeNode161.Text = "房间9";
            treeNode162.Name = "TreeAreaMark_4";
            treeNode162.Tag = "4";
            treeNode162.Text = "高手区一";
            treeNode163.Name = "Room_1";
            treeNode163.Tag = "1";
            treeNode163.Text = "房间1";
            treeNode164.Name = "Room_2";
            treeNode164.Tag = "2";
            treeNode164.Text = "房间2";
            treeNode165.Name = "Room_3";
            treeNode165.Tag = "3";
            treeNode165.Text = "房间3";
            treeNode166.Name = "Room_4";
            treeNode166.Tag = "4";
            treeNode166.Text = "房间4";
            treeNode167.Name = "Room_5";
            treeNode167.Tag = "5";
            treeNode167.Text = "房间5";
            treeNode168.Name = "Room_6";
            treeNode168.Tag = "6";
            treeNode168.Text = "房间6";
            treeNode169.Name = "Room_7";
            treeNode169.Tag = "7";
            treeNode169.Text = "房间7";
            treeNode170.Name = "Room_8";
            treeNode170.Tag = "8";
            treeNode170.Text = "房间8";
            treeNode171.Name = "Room_9";
            treeNode171.Tag = "9";
            treeNode171.Text = "房间9";
            treeNode172.Name = "TreeAreaMark_5";
            treeNode172.Tag = "5";
            treeNode172.Text = "高手区二";
            treeNode173.Name = "Room_1";
            treeNode173.Tag = "1";
            treeNode173.Text = "房间1";
            treeNode174.Name = "Room_2";
            treeNode174.Tag = "2";
            treeNode174.Text = "房间2";
            treeNode175.Name = "Room_3";
            treeNode175.Tag = "3";
            treeNode175.Text = "房间3";
            treeNode176.Name = "Room_4";
            treeNode176.Tag = "4";
            treeNode176.Text = "房间4";
            treeNode177.Name = "Room_5";
            treeNode177.Tag = "5";
            treeNode177.Text = "房间5";
            treeNode178.Name = "Room_6";
            treeNode178.Tag = "6";
            treeNode178.Text = "房间6";
            treeNode179.Name = "Room_7";
            treeNode179.Tag = "7";
            treeNode179.Text = "房间7";
            treeNode180.Name = "Room_8";
            treeNode180.Tag = "8";
            treeNode180.Text = "房间8";
            treeNode181.Name = "Room_9";
            treeNode181.Tag = "9";
            treeNode181.Text = "房间9";
            treeNode182.Name = "TreeAreaMark_6";
            treeNode182.Tag = "6";
            treeNode182.Text = "高手区三";
            treeNode183.Name = "TreeBaseTit";
            treeNode183.Tag = "0";
            treeNode183.Text = "五子棋";
            this.treeView_Area.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode183});
            this.treeView_Area.ShowRootLines = false;
            this.treeView_Area.Size = new System.Drawing.Size(200, 439);
            this.treeView_Area.TabIndex = 1;
            this.treeView_Area.BeforeCollapse += new System.Windows.Forms.TreeViewCancelEventHandler(this.treeView_Area_BeforeCollapse);
            this.treeView_Area.NodeMouseDoubleClick += new System.Windows.Forms.TreeNodeMouseClickEventHandler(this.treeView_Area_NodeMouseDoubleClick);
            // 
            // panel_TreeT
            // 
            this.panel_TreeT.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.panel_TreeT.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel_TreeT.BackgroundImage")));
            this.panel_TreeT.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel_TreeT.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_TreeT.Location = new System.Drawing.Point(0, 0);
            this.panel_TreeT.Name = "panel_TreeT";
            this.panel_TreeT.Size = new System.Drawing.Size(200, 26);
            this.panel_TreeT.TabIndex = 0;
            // 
            // panel_LAmong
            // 
            this.panel_LAmong.BackColor = System.Drawing.Color.Transparent;
            this.panel_LAmong.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel_LAmong.BackgroundImage")));
            this.panel_LAmong.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel_LAmong.Controls.Add(this.pictureBox_LA);
            this.panel_LAmong.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel_LAmong.Location = new System.Drawing.Point(203, 99);
            this.panel_LAmong.Name = "panel_LAmong";
            this.panel_LAmong.Size = new System.Drawing.Size(7, 465);
            this.panel_LAmong.TabIndex = 7;
            // 
            // pictureBox_LA
            // 
            this.pictureBox_LA.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox_LA.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox_LA.Image")));
            this.pictureBox_LA.Location = new System.Drawing.Point(1, 174);
            this.pictureBox_LA.Name = "pictureBox_LA";
            this.pictureBox_LA.Size = new System.Drawing.Size(5, 93);
            this.pictureBox_LA.TabIndex = 0;
            this.pictureBox_LA.TabStop = false;
            this.pictureBox_LA.Click += new System.EventHandler(this.pictureBox_LA_Click);
            // 
            // panel_Public
            // 
            this.panel_Public.Controls.Add(this.panel3);
            this.panel_Public.Controls.Add(this.panel_DialogB);
            this.panel_Public.Controls.Add(this.panel_DialogTit);
            this.panel_Public.Controls.Add(this.listView_user);
            this.panel_Public.Controls.Add(this.panel_PerTit);
            this.panel_Public.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel_Public.Location = new System.Drawing.Point(704, 99);
            this.panel_Public.Name = "panel_Public";
            this.panel_Public.Size = new System.Drawing.Size(220, 465);
            this.panel_Public.TabIndex = 8;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.RTB_Dialog);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(0, 227);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(220, 198);
            this.panel3.TabIndex = 5;
            // 
            // RTB_Dialog
            // 
            this.RTB_Dialog.Dock = System.Windows.Forms.DockStyle.Fill;
            this.RTB_Dialog.Location = new System.Drawing.Point(0, 0);
            this.RTB_Dialog.Name = "RTB_Dialog";
            this.RTB_Dialog.Size = new System.Drawing.Size(220, 198);
            this.RTB_Dialog.TabIndex = 0;
            this.RTB_Dialog.Text = "";
            // 
            // panel_DialogB
            // 
            this.panel_DialogB.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.panel_DialogB.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel_DialogB.BackgroundImage")));
            this.panel_DialogB.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel_DialogB.Controls.Add(this.pictureBox_Hair);
            this.panel_DialogB.Controls.Add(this.comboBox_Hair);
            this.panel_DialogB.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel_DialogB.Location = new System.Drawing.Point(0, 425);
            this.panel_DialogB.Name = "panel_DialogB";
            this.panel_DialogB.Size = new System.Drawing.Size(220, 40);
            this.panel_DialogB.TabIndex = 4;
            // 
            // pictureBox_Hair
            // 
            this.pictureBox_Hair.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox_Hair.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox_Hair.Image")));
            this.pictureBox_Hair.Location = new System.Drawing.Point(180, 10);
            this.pictureBox_Hair.Name = "pictureBox_Hair";
            this.pictureBox_Hair.Size = new System.Drawing.Size(35, 18);
            this.pictureBox_Hair.TabIndex = 1;
            this.pictureBox_Hair.TabStop = false;
            this.pictureBox_Hair.Tag = "4";
            this.pictureBox_Hair.Click += new System.EventHandler(this.pictureBox_Hair_Click);
            this.pictureBox_Hair.MouseEnter += new System.EventHandler(this.Image_Min_MouseEnter);
            this.pictureBox_Hair.MouseLeave += new System.EventHandler(this.Image_Min_MouseLeave);
            // 
            // comboBox_Hair
            // 
            this.comboBox_Hair.FormattingEnabled = true;
            this.comboBox_Hair.Items.AddRange(new object[] {
            "大家好。",
            "今天的人怎么这么多呀。",
            "小弟（妹）初来，请大家多多关照。"});
            this.comboBox_Hair.Location = new System.Drawing.Point(7, 9);
            this.comboBox_Hair.Name = "comboBox_Hair";
            this.comboBox_Hair.Size = new System.Drawing.Size(167, 20);
            this.comboBox_Hair.TabIndex = 0;
            this.comboBox_Hair.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.comboBox_Hair_KeyPress);
            // 
            // panel_DialogTit
            // 
            this.panel_DialogTit.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.panel_DialogTit.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel_DialogTit.BackgroundImage")));
            this.panel_DialogTit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel_DialogTit.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_DialogTit.Location = new System.Drawing.Point(0, 201);
            this.panel_DialogTit.Name = "panel_DialogTit";
            this.panel_DialogTit.Size = new System.Drawing.Size(220, 26);
            this.panel_DialogTit.TabIndex = 2;
            // 
            // listView_user
            // 
            this.listView_user.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.listView_user.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3});
            this.listView_user.Dock = System.Windows.Forms.DockStyle.Top;
            this.listView_user.Location = new System.Drawing.Point(0, 26);
            this.listView_user.Name = "listView_user";
            this.listView_user.Size = new System.Drawing.Size(220, 175);
            this.listView_user.TabIndex = 1;
            this.listView_user.UseCompatibleStateImageBehavior = false;
            // 
            // panel_PerTit
            // 
            this.panel_PerTit.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.panel_PerTit.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel_PerTit.BackgroundImage")));
            this.panel_PerTit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel_PerTit.Controls.Add(this.pictureBox65);
            this.panel_PerTit.Controls.Add(this.pictureBox64);
            this.panel_PerTit.Controls.Add(this.label5);
            this.panel_PerTit.Controls.Add(this.label4);
            this.panel_PerTit.Controls.Add(this.label2);
            this.panel_PerTit.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_PerTit.Location = new System.Drawing.Point(0, 0);
            this.panel_PerTit.Name = "panel_PerTit";
            this.panel_PerTit.Size = new System.Drawing.Size(220, 26);
            this.panel_PerTit.TabIndex = 0;
            // 
            // pictureBox65
            // 
            this.pictureBox65.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox65.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox65.Image")));
            this.pictureBox65.Location = new System.Drawing.Point(151, 1);
            this.pictureBox65.Name = "pictureBox65";
            this.pictureBox65.Size = new System.Drawing.Size(2, 25);
            this.pictureBox65.TabIndex = 2;
            this.pictureBox65.TabStop = false;
            // 
            // pictureBox64
            // 
            this.pictureBox64.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox64.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox64.Image")));
            this.pictureBox64.Location = new System.Drawing.Point(42, 0);
            this.pictureBox64.Name = "pictureBox64";
            this.pictureBox64.Size = new System.Drawing.Size(2, 25);
            this.pictureBox64.TabIndex = 1;
            this.pictureBox64.TabStop = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("幼圆", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label5.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.label5.Location = new System.Drawing.Point(154, 7);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(37, 14);
            this.label5.TabIndex = 0;
            this.label5.Text = "分数";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("幼圆", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.label4.Location = new System.Drawing.Point(47, 7);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(52, 14);
            this.label4.TabIndex = 0;
            this.label4.Text = "用户名";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("幼圆", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.label2.Location = new System.Drawing.Point(3, 7);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 14);
            this.label2.TabIndex = 0;
            this.label2.Text = "头像";
            // 
            // imageList2
            // 
            this.imageList2.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList2.ImageStream")));
            this.imageList2.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList2.Images.SetKeyName(0, "头像1.png");
            this.imageList2.Images.SetKeyName(1, "头像2.png");
            this.imageList2.Images.SetKeyName(2, "头像3.png");
            this.imageList2.Images.SetKeyName(3, "头像4.png");
            this.imageList2.Images.SetKeyName(4, "头像5.png");
            this.imageList2.Images.SetKeyName(5, "头像6.png");
            this.imageList2.Images.SetKeyName(6, "无人时的问号.png");
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "头像1.png");
            this.imageList1.Images.SetKeyName(1, "头像2.png");
            this.imageList1.Images.SetKeyName(2, "头像3.png");
            this.imageList1.Images.SetKeyName(3, "头像4.png");
            this.imageList1.Images.SetKeyName(4, "头像5.png");
            this.imageList1.Images.SetKeyName(5, "头像6.png");
            this.imageList1.Images.SetKeyName(6, "无人时的问号.png");
            // 
            // panel_RA
            // 
            this.panel_RA.BackColor = System.Drawing.SystemColors.HotTrack;
            this.panel_RA.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel_RA.BackgroundImage")));
            this.panel_RA.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel_RA.Controls.Add(this.pictureBox1);
            this.panel_RA.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel_RA.Location = new System.Drawing.Point(697, 99);
            this.panel_RA.Name = "panel_RA";
            this.panel_RA.Size = new System.Drawing.Size(7, 465);
            this.panel_RA.TabIndex = 9;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(1, 174);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(5, 93);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // panel_OpposeTit
            // 
            this.panel_OpposeTit.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.panel_OpposeTit.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_OpposeTit.Location = new System.Drawing.Point(210, 99);
            this.panel_OpposeTit.Name = "panel_OpposeTit";
            this.panel_OpposeTit.Size = new System.Drawing.Size(487, 0);
            this.panel_OpposeTit.TabIndex = 10;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.panel2.Controls.Add(this.pictureBox_Back);
            this.panel2.Controls.Add(this.flowPanel_Oppose);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(210, 99);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(487, 465);
            this.panel2.TabIndex = 11;
            // 
            // pictureBox_Back
            // 
            this.pictureBox_Back.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox_Back.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox_Back.Image")));
            this.pictureBox_Back.Location = new System.Drawing.Point(285, 174);
            this.pictureBox_Back.Name = "pictureBox_Back";
            this.pictureBox_Back.Size = new System.Drawing.Size(127, 129);
            this.pictureBox_Back.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_Back.TabIndex = 13;
            this.pictureBox_Back.TabStop = false;
            // 
            // flowPanel_Oppose
            // 
            this.flowPanel_Oppose.AutoScroll = true;
            this.flowPanel_Oppose.BackColor = System.Drawing.Color.Peru;
            this.flowPanel_Oppose.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("flowPanel_Oppose.BackgroundImage")));
            this.flowPanel_Oppose.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.flowPanel_Oppose.Controls.Add(this.Desk_01);
            this.flowPanel_Oppose.Controls.Add(this.Desk_02);
            this.flowPanel_Oppose.Controls.Add(this.Desk_03);
            this.flowPanel_Oppose.Controls.Add(this.Desk_04);
            this.flowPanel_Oppose.Controls.Add(this.Desk_05);
            this.flowPanel_Oppose.Controls.Add(this.Desk_06);
            this.flowPanel_Oppose.Controls.Add(this.Desk_07);
            this.flowPanel_Oppose.Controls.Add(this.Desk_08);
            this.flowPanel_Oppose.Controls.Add(this.Desk_09);
            this.flowPanel_Oppose.Controls.Add(this.Desk_10);
            this.flowPanel_Oppose.Controls.Add(this.Desk_11);
            this.flowPanel_Oppose.Controls.Add(this.Desk_12);
            this.flowPanel_Oppose.Controls.Add(this.Desk_13);
            this.flowPanel_Oppose.Controls.Add(this.Desk_14);
            this.flowPanel_Oppose.Controls.Add(this.Desk_15);
            this.flowPanel_Oppose.Controls.Add(this.Desk_16);
            this.flowPanel_Oppose.Controls.Add(this.Desk_17);
            this.flowPanel_Oppose.Controls.Add(this.Desk_18);
            this.flowPanel_Oppose.Controls.Add(this.Desk_19);
            this.flowPanel_Oppose.Controls.Add(this.Desk_20);
            this.flowPanel_Oppose.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowPanel_Oppose.ForeColor = System.Drawing.Color.White;
            this.flowPanel_Oppose.Location = new System.Drawing.Point(0, 0);
            this.flowPanel_Oppose.Name = "flowPanel_Oppose";
            this.flowPanel_Oppose.Size = new System.Drawing.Size(487, 465);
            this.flowPanel_Oppose.TabIndex = 12;
            this.flowPanel_Oppose.Visible = false;
            // 
            // Desk_01
            // 
            this.Desk_01.BackColor = System.Drawing.Color.Transparent;
            this.Desk_01.Controls.Add(this.label1_2);
            this.Desk_01.Controls.Add(this.label2_1);
            this.Desk_01.Controls.Add(this.label3);
            this.Desk_01.Controls.Add(this.pictureBox2);
            this.Desk_01.Controls.Add(this.pictureBox3);
            this.Desk_01.Controls.Add(this.pictureBox4);
            this.Desk_01.Location = new System.Drawing.Point(3, 3);
            this.Desk_01.Name = "Desk_01";
            this.Desk_01.Size = new System.Drawing.Size(140, 100);
            this.Desk_01.TabIndex = 2;
            this.Desk_01.Tag = "1";
            // 
            // label1_2
            // 
            this.label1_2.AutoSize = true;
            this.label1_2.Location = new System.Drawing.Point(93, 76);
            this.label1_2.Name = "label1_2";
            this.label1_2.Size = new System.Drawing.Size(41, 12);
            this.label1_2.TabIndex = 5;
            this.label1_2.Text = "label2";
            // 
            // label2_1
            // 
            this.label2_1.AutoSize = true;
            this.label2_1.Location = new System.Drawing.Point(7, 6);
            this.label2_1.Name = "label2_1";
            this.label2_1.Size = new System.Drawing.Size(41, 12);
            this.label2_1.TabIndex = 4;
            this.label2_1.Text = "label1";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(50, 84);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 12);
            this.label3.TabIndex = 3;
            this.label3.Text = "- 01 -";
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Location = new System.Drawing.Point(100, 31);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(32, 32);
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Tag = "2";
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.AccessibleDescription = "";
            this.pictureBox3.AccessibleName = "";
            this.pictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox3.Location = new System.Drawing.Point(9, 31);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(32, 32);
            this.pictureBox3.TabIndex = 1;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Tag = "1";
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(45, 22);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(50, 50);
            this.pictureBox4.TabIndex = 0;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Tag = "0";
            // 
            // Desk_02
            // 
            this.Desk_02.BackColor = System.Drawing.Color.Transparent;
            this.Desk_02.Controls.Add(this.label4_2);
            this.Desk_02.Controls.Add(this.label5_1);
            this.Desk_02.Controls.Add(this.label6);
            this.Desk_02.Controls.Add(this.pictureBox5);
            this.Desk_02.Controls.Add(this.pictureBox6);
            this.Desk_02.Controls.Add(this.pictureBox7);
            this.Desk_02.Location = new System.Drawing.Point(149, 3);
            this.Desk_02.Name = "Desk_02";
            this.Desk_02.Size = new System.Drawing.Size(140, 100);
            this.Desk_02.TabIndex = 6;
            this.Desk_02.Tag = "2";
            // 
            // label4_2
            // 
            this.label4_2.AutoSize = true;
            this.label4_2.Location = new System.Drawing.Point(94, 76);
            this.label4_2.Name = "label4_2";
            this.label4_2.Size = new System.Drawing.Size(41, 12);
            this.label4_2.TabIndex = 5;
            this.label4_2.Text = "label2";
            // 
            // label5_1
            // 
            this.label5_1.AutoSize = true;
            this.label5_1.Location = new System.Drawing.Point(7, 6);
            this.label5_1.Name = "label5_1";
            this.label5_1.Size = new System.Drawing.Size(41, 12);
            this.label5_1.TabIndex = 4;
            this.label5_1.Text = "label1";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(51, 84);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(41, 12);
            this.label6.TabIndex = 3;
            this.label6.Text = "- 02 -";
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox5.Location = new System.Drawing.Point(100, 31);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(32, 32);
            this.pictureBox5.TabIndex = 2;
            this.pictureBox5.TabStop = false;
            this.pictureBox5.Tag = "2";
            this.pictureBox5.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox6.Location = new System.Drawing.Point(9, 31);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(32, 32);
            this.pictureBox6.TabIndex = 1;
            this.pictureBox6.TabStop = false;
            this.pictureBox6.Tag = "1";
            this.pictureBox6.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox7
            // 
            this.pictureBox7.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.pictureBox7.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox7.Image")));
            this.pictureBox7.Location = new System.Drawing.Point(45, 22);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(50, 50);
            this.pictureBox7.TabIndex = 0;
            this.pictureBox7.TabStop = false;
            this.pictureBox7.Tag = "0";
            // 
            // Desk_03
            // 
            this.Desk_03.BackColor = System.Drawing.Color.Transparent;
            this.Desk_03.Controls.Add(this.label7_2);
            this.Desk_03.Controls.Add(this.label8_1);
            this.Desk_03.Controls.Add(this.label9);
            this.Desk_03.Controls.Add(this.pictureBox8);
            this.Desk_03.Controls.Add(this.pictureBox9);
            this.Desk_03.Controls.Add(this.pictureBox10);
            this.Desk_03.Location = new System.Drawing.Point(295, 3);
            this.Desk_03.Name = "Desk_03";
            this.Desk_03.Size = new System.Drawing.Size(140, 100);
            this.Desk_03.TabIndex = 7;
            this.Desk_03.Tag = "3";
            // 
            // label7_2
            // 
            this.label7_2.AutoSize = true;
            this.label7_2.Location = new System.Drawing.Point(94, 76);
            this.label7_2.Name = "label7_2";
            this.label7_2.Size = new System.Drawing.Size(41, 12);
            this.label7_2.TabIndex = 5;
            this.label7_2.Text = "label2";
            // 
            // label8_1
            // 
            this.label8_1.AutoSize = true;
            this.label8_1.Location = new System.Drawing.Point(7, 6);
            this.label8_1.Name = "label8_1";
            this.label8_1.Size = new System.Drawing.Size(41, 12);
            this.label8_1.TabIndex = 4;
            this.label8_1.Text = "label1";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(51, 84);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(41, 12);
            this.label9.TabIndex = 3;
            this.label9.Text = "- 03 -";
            // 
            // pictureBox8
            // 
            this.pictureBox8.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox8.Location = new System.Drawing.Point(100, 31);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(32, 32);
            this.pictureBox8.TabIndex = 2;
            this.pictureBox8.TabStop = false;
            this.pictureBox8.Tag = "2";
            this.pictureBox8.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox9
            // 
            this.pictureBox9.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox9.Location = new System.Drawing.Point(9, 31);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(32, 32);
            this.pictureBox9.TabIndex = 1;
            this.pictureBox9.TabStop = false;
            this.pictureBox9.Tag = "1";
            this.pictureBox9.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox10
            // 
            this.pictureBox10.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.pictureBox10.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox10.Image")));
            this.pictureBox10.Location = new System.Drawing.Point(45, 22);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(50, 50);
            this.pictureBox10.TabIndex = 0;
            this.pictureBox10.TabStop = false;
            this.pictureBox10.Tag = "0";
            // 
            // Desk_04
            // 
            this.Desk_04.BackColor = System.Drawing.Color.Transparent;
            this.Desk_04.Controls.Add(this.label10_2);
            this.Desk_04.Controls.Add(this.label11_1);
            this.Desk_04.Controls.Add(this.label12);
            this.Desk_04.Controls.Add(this.pictureBox11);
            this.Desk_04.Controls.Add(this.pictureBox12);
            this.Desk_04.Controls.Add(this.pictureBox13);
            this.Desk_04.Location = new System.Drawing.Point(3, 109);
            this.Desk_04.Name = "Desk_04";
            this.Desk_04.Size = new System.Drawing.Size(140, 100);
            this.Desk_04.TabIndex = 6;
            this.Desk_04.Tag = "4";
            // 
            // label10_2
            // 
            this.label10_2.AutoSize = true;
            this.label10_2.Location = new System.Drawing.Point(94, 76);
            this.label10_2.Name = "label10_2";
            this.label10_2.Size = new System.Drawing.Size(41, 12);
            this.label10_2.TabIndex = 5;
            this.label10_2.Text = "label2";
            // 
            // label11_1
            // 
            this.label11_1.AutoSize = true;
            this.label11_1.Location = new System.Drawing.Point(7, 6);
            this.label11_1.Name = "label11_1";
            this.label11_1.Size = new System.Drawing.Size(41, 12);
            this.label11_1.TabIndex = 4;
            this.label11_1.Text = "label1";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(51, 84);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(41, 12);
            this.label12.TabIndex = 3;
            this.label12.Text = "- 04 -";
            // 
            // pictureBox11
            // 
            this.pictureBox11.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox11.Location = new System.Drawing.Point(100, 31);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(32, 32);
            this.pictureBox11.TabIndex = 2;
            this.pictureBox11.TabStop = false;
            this.pictureBox11.Tag = "2";
            this.pictureBox11.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox12
            // 
            this.pictureBox12.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox12.Location = new System.Drawing.Point(9, 31);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(32, 32);
            this.pictureBox12.TabIndex = 1;
            this.pictureBox12.TabStop = false;
            this.pictureBox12.Tag = "1";
            this.pictureBox12.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox13
            // 
            this.pictureBox13.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.pictureBox13.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox13.Image")));
            this.pictureBox13.Location = new System.Drawing.Point(45, 22);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(50, 50);
            this.pictureBox13.TabIndex = 0;
            this.pictureBox13.TabStop = false;
            this.pictureBox13.Tag = "0";
            // 
            // Desk_05
            // 
            this.Desk_05.BackColor = System.Drawing.Color.Transparent;
            this.Desk_05.Controls.Add(this.label16_2);
            this.Desk_05.Controls.Add(this.label17_1);
            this.Desk_05.Controls.Add(this.label18);
            this.Desk_05.Controls.Add(this.pictureBox17);
            this.Desk_05.Controls.Add(this.pictureBox18);
            this.Desk_05.Controls.Add(this.pictureBox19);
            this.Desk_05.Location = new System.Drawing.Point(149, 109);
            this.Desk_05.Name = "Desk_05";
            this.Desk_05.Size = new System.Drawing.Size(140, 100);
            this.Desk_05.TabIndex = 6;
            this.Desk_05.Tag = "5";
            // 
            // label16_2
            // 
            this.label16_2.AutoSize = true;
            this.label16_2.Location = new System.Drawing.Point(94, 76);
            this.label16_2.Name = "label16_2";
            this.label16_2.Size = new System.Drawing.Size(41, 12);
            this.label16_2.TabIndex = 5;
            this.label16_2.Text = "label2";
            // 
            // label17_1
            // 
            this.label17_1.AutoSize = true;
            this.label17_1.Location = new System.Drawing.Point(7, 6);
            this.label17_1.Name = "label17_1";
            this.label17_1.Size = new System.Drawing.Size(41, 12);
            this.label17_1.TabIndex = 4;
            this.label17_1.Text = "label1";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(50, 84);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(41, 12);
            this.label18.TabIndex = 3;
            this.label18.Text = "- 05 -";
            // 
            // pictureBox17
            // 
            this.pictureBox17.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox17.Location = new System.Drawing.Point(100, 31);
            this.pictureBox17.Name = "pictureBox17";
            this.pictureBox17.Size = new System.Drawing.Size(32, 32);
            this.pictureBox17.TabIndex = 2;
            this.pictureBox17.TabStop = false;
            this.pictureBox17.Tag = "2";
            this.pictureBox17.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox18
            // 
            this.pictureBox18.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox18.Location = new System.Drawing.Point(9, 31);
            this.pictureBox18.Name = "pictureBox18";
            this.pictureBox18.Size = new System.Drawing.Size(32, 32);
            this.pictureBox18.TabIndex = 1;
            this.pictureBox18.TabStop = false;
            this.pictureBox18.Tag = "1";
            this.pictureBox18.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox19
            // 
            this.pictureBox19.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.pictureBox19.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox19.Image")));
            this.pictureBox19.Location = new System.Drawing.Point(45, 22);
            this.pictureBox19.Name = "pictureBox19";
            this.pictureBox19.Size = new System.Drawing.Size(50, 50);
            this.pictureBox19.TabIndex = 0;
            this.pictureBox19.TabStop = false;
            this.pictureBox19.Tag = "0";
            // 
            // Desk_06
            // 
            this.Desk_06.BackColor = System.Drawing.Color.Transparent;
            this.Desk_06.Controls.Add(this.label13_2);
            this.Desk_06.Controls.Add(this.label14_1);
            this.Desk_06.Controls.Add(this.label15);
            this.Desk_06.Controls.Add(this.pictureBox14);
            this.Desk_06.Controls.Add(this.pictureBox15);
            this.Desk_06.Controls.Add(this.pictureBox16);
            this.Desk_06.Location = new System.Drawing.Point(295, 109);
            this.Desk_06.Name = "Desk_06";
            this.Desk_06.Size = new System.Drawing.Size(140, 100);
            this.Desk_06.TabIndex = 6;
            this.Desk_06.Tag = "6";
            // 
            // label13_2
            // 
            this.label13_2.AutoSize = true;
            this.label13_2.Location = new System.Drawing.Point(94, 76);
            this.label13_2.Name = "label13_2";
            this.label13_2.Size = new System.Drawing.Size(41, 12);
            this.label13_2.TabIndex = 5;
            this.label13_2.Text = "label2";
            // 
            // label14_1
            // 
            this.label14_1.AutoSize = true;
            this.label14_1.Location = new System.Drawing.Point(7, 6);
            this.label14_1.Name = "label14_1";
            this.label14_1.Size = new System.Drawing.Size(41, 12);
            this.label14_1.TabIndex = 4;
            this.label14_1.Text = "label1";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(51, 84);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(41, 12);
            this.label15.TabIndex = 3;
            this.label15.Text = "- 06 -";
            // 
            // pictureBox14
            // 
            this.pictureBox14.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox14.Location = new System.Drawing.Point(100, 31);
            this.pictureBox14.Name = "pictureBox14";
            this.pictureBox14.Size = new System.Drawing.Size(32, 32);
            this.pictureBox14.TabIndex = 2;
            this.pictureBox14.TabStop = false;
            this.pictureBox14.Tag = "2";
            this.pictureBox14.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox15
            // 
            this.pictureBox15.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox15.Location = new System.Drawing.Point(9, 31);
            this.pictureBox15.Name = "pictureBox15";
            this.pictureBox15.Size = new System.Drawing.Size(32, 32);
            this.pictureBox15.TabIndex = 1;
            this.pictureBox15.TabStop = false;
            this.pictureBox15.Tag = "1";
            this.pictureBox15.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox16
            // 
            this.pictureBox16.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.pictureBox16.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox16.Image")));
            this.pictureBox16.Location = new System.Drawing.Point(45, 22);
            this.pictureBox16.Name = "pictureBox16";
            this.pictureBox16.Size = new System.Drawing.Size(50, 50);
            this.pictureBox16.TabIndex = 0;
            this.pictureBox16.TabStop = false;
            this.pictureBox16.Tag = "0";
            // 
            // Desk_07
            // 
            this.Desk_07.BackColor = System.Drawing.Color.Transparent;
            this.Desk_07.Controls.Add(this.label19_2);
            this.Desk_07.Controls.Add(this.label20_1);
            this.Desk_07.Controls.Add(this.label21);
            this.Desk_07.Controls.Add(this.pictureBox20);
            this.Desk_07.Controls.Add(this.pictureBox21);
            this.Desk_07.Controls.Add(this.pictureBox22);
            this.Desk_07.Location = new System.Drawing.Point(3, 215);
            this.Desk_07.Name = "Desk_07";
            this.Desk_07.Size = new System.Drawing.Size(140, 100);
            this.Desk_07.TabIndex = 8;
            this.Desk_07.Tag = "7";
            // 
            // label19_2
            // 
            this.label19_2.AutoSize = true;
            this.label19_2.Location = new System.Drawing.Point(94, 76);
            this.label19_2.Name = "label19_2";
            this.label19_2.Size = new System.Drawing.Size(41, 12);
            this.label19_2.TabIndex = 5;
            this.label19_2.Text = "label2";
            // 
            // label20_1
            // 
            this.label20_1.AutoSize = true;
            this.label20_1.Location = new System.Drawing.Point(7, 6);
            this.label20_1.Name = "label20_1";
            this.label20_1.Size = new System.Drawing.Size(41, 12);
            this.label20_1.TabIndex = 4;
            this.label20_1.Text = "label1";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(50, 84);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(41, 12);
            this.label21.TabIndex = 3;
            this.label21.Text = "- 07 -";
            // 
            // pictureBox20
            // 
            this.pictureBox20.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox20.Location = new System.Drawing.Point(100, 31);
            this.pictureBox20.Name = "pictureBox20";
            this.pictureBox20.Size = new System.Drawing.Size(32, 32);
            this.pictureBox20.TabIndex = 2;
            this.pictureBox20.TabStop = false;
            this.pictureBox20.Tag = "2";
            this.pictureBox20.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox21
            // 
            this.pictureBox21.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox21.Location = new System.Drawing.Point(9, 31);
            this.pictureBox21.Name = "pictureBox21";
            this.pictureBox21.Size = new System.Drawing.Size(32, 32);
            this.pictureBox21.TabIndex = 1;
            this.pictureBox21.TabStop = false;
            this.pictureBox21.Tag = "1";
            this.pictureBox21.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox22
            // 
            this.pictureBox22.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.pictureBox22.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox22.Image")));
            this.pictureBox22.Location = new System.Drawing.Point(45, 22);
            this.pictureBox22.Name = "pictureBox22";
            this.pictureBox22.Size = new System.Drawing.Size(50, 50);
            this.pictureBox22.TabIndex = 0;
            this.pictureBox22.TabStop = false;
            this.pictureBox22.Tag = "0";
            // 
            // Desk_08
            // 
            this.Desk_08.BackColor = System.Drawing.Color.Transparent;
            this.Desk_08.Controls.Add(this.label22_2);
            this.Desk_08.Controls.Add(this.label23_1);
            this.Desk_08.Controls.Add(this.label24);
            this.Desk_08.Controls.Add(this.pictureBox23);
            this.Desk_08.Controls.Add(this.pictureBox24);
            this.Desk_08.Controls.Add(this.pictureBox25);
            this.Desk_08.Location = new System.Drawing.Point(149, 215);
            this.Desk_08.Name = "Desk_08";
            this.Desk_08.Size = new System.Drawing.Size(140, 100);
            this.Desk_08.TabIndex = 6;
            this.Desk_08.Tag = "8";
            // 
            // label22_2
            // 
            this.label22_2.AutoSize = true;
            this.label22_2.Location = new System.Drawing.Point(94, 76);
            this.label22_2.Name = "label22_2";
            this.label22_2.Size = new System.Drawing.Size(41, 12);
            this.label22_2.TabIndex = 5;
            this.label22_2.Text = "label2";
            // 
            // label23_1
            // 
            this.label23_1.AutoSize = true;
            this.label23_1.Location = new System.Drawing.Point(7, 6);
            this.label23_1.Name = "label23_1";
            this.label23_1.Size = new System.Drawing.Size(41, 12);
            this.label23_1.TabIndex = 4;
            this.label23_1.Text = "label1";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(50, 84);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(41, 12);
            this.label24.TabIndex = 3;
            this.label24.Text = "- 08 -";
            // 
            // pictureBox23
            // 
            this.pictureBox23.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox23.Location = new System.Drawing.Point(100, 31);
            this.pictureBox23.Name = "pictureBox23";
            this.pictureBox23.Size = new System.Drawing.Size(32, 32);
            this.pictureBox23.TabIndex = 2;
            this.pictureBox23.TabStop = false;
            this.pictureBox23.Tag = "2";
            this.pictureBox23.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox24
            // 
            this.pictureBox24.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox24.Location = new System.Drawing.Point(9, 31);
            this.pictureBox24.Name = "pictureBox24";
            this.pictureBox24.Size = new System.Drawing.Size(32, 32);
            this.pictureBox24.TabIndex = 1;
            this.pictureBox24.TabStop = false;
            this.pictureBox24.Tag = "1";
            this.pictureBox24.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox25
            // 
            this.pictureBox25.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.pictureBox25.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox25.Image")));
            this.pictureBox25.Location = new System.Drawing.Point(45, 22);
            this.pictureBox25.Name = "pictureBox25";
            this.pictureBox25.Size = new System.Drawing.Size(50, 50);
            this.pictureBox25.TabIndex = 0;
            this.pictureBox25.TabStop = false;
            this.pictureBox25.Tag = "0";
            // 
            // Desk_09
            // 
            this.Desk_09.BackColor = System.Drawing.Color.Transparent;
            this.Desk_09.Controls.Add(this.label25_2);
            this.Desk_09.Controls.Add(this.label26_1);
            this.Desk_09.Controls.Add(this.label27);
            this.Desk_09.Controls.Add(this.pictureBox26);
            this.Desk_09.Controls.Add(this.pictureBox27);
            this.Desk_09.Controls.Add(this.pictureBox28);
            this.Desk_09.Location = new System.Drawing.Point(295, 215);
            this.Desk_09.Name = "Desk_09";
            this.Desk_09.Size = new System.Drawing.Size(140, 100);
            this.Desk_09.TabIndex = 9;
            this.Desk_09.Tag = "9";
            // 
            // label25_2
            // 
            this.label25_2.AutoSize = true;
            this.label25_2.Location = new System.Drawing.Point(94, 76);
            this.label25_2.Name = "label25_2";
            this.label25_2.Size = new System.Drawing.Size(41, 12);
            this.label25_2.TabIndex = 5;
            this.label25_2.Text = "label2";
            // 
            // label26_1
            // 
            this.label26_1.AutoSize = true;
            this.label26_1.Location = new System.Drawing.Point(7, 6);
            this.label26_1.Name = "label26_1";
            this.label26_1.Size = new System.Drawing.Size(41, 12);
            this.label26_1.TabIndex = 4;
            this.label26_1.Text = "label1";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(50, 84);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(41, 12);
            this.label27.TabIndex = 3;
            this.label27.Text = "- 09 -";
            // 
            // pictureBox26
            // 
            this.pictureBox26.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox26.Location = new System.Drawing.Point(100, 31);
            this.pictureBox26.Name = "pictureBox26";
            this.pictureBox26.Size = new System.Drawing.Size(32, 32);
            this.pictureBox26.TabIndex = 2;
            this.pictureBox26.TabStop = false;
            this.pictureBox26.Tag = "2";
            this.pictureBox26.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox27
            // 
            this.pictureBox27.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox27.Location = new System.Drawing.Point(9, 31);
            this.pictureBox27.Name = "pictureBox27";
            this.pictureBox27.Size = new System.Drawing.Size(32, 32);
            this.pictureBox27.TabIndex = 1;
            this.pictureBox27.TabStop = false;
            this.pictureBox27.Tag = "1";
            this.pictureBox27.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox28
            // 
            this.pictureBox28.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.pictureBox28.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox28.Image")));
            this.pictureBox28.Location = new System.Drawing.Point(45, 22);
            this.pictureBox28.Name = "pictureBox28";
            this.pictureBox28.Size = new System.Drawing.Size(50, 50);
            this.pictureBox28.TabIndex = 0;
            this.pictureBox28.TabStop = false;
            this.pictureBox28.Tag = "0";
            // 
            // Desk_10
            // 
            this.Desk_10.BackColor = System.Drawing.Color.Transparent;
            this.Desk_10.Controls.Add(this.label28_2);
            this.Desk_10.Controls.Add(this.label29_1);
            this.Desk_10.Controls.Add(this.label30);
            this.Desk_10.Controls.Add(this.pictureBox29);
            this.Desk_10.Controls.Add(this.pictureBox30);
            this.Desk_10.Controls.Add(this.pictureBox31);
            this.Desk_10.Location = new System.Drawing.Point(3, 321);
            this.Desk_10.Name = "Desk_10";
            this.Desk_10.Size = new System.Drawing.Size(140, 100);
            this.Desk_10.TabIndex = 10;
            this.Desk_10.Tag = "10";
            // 
            // label28_2
            // 
            this.label28_2.AutoSize = true;
            this.label28_2.Location = new System.Drawing.Point(94, 76);
            this.label28_2.Name = "label28_2";
            this.label28_2.Size = new System.Drawing.Size(41, 12);
            this.label28_2.TabIndex = 5;
            this.label28_2.Text = "label2";
            // 
            // label29_1
            // 
            this.label29_1.AutoSize = true;
            this.label29_1.Location = new System.Drawing.Point(7, 6);
            this.label29_1.Name = "label29_1";
            this.label29_1.Size = new System.Drawing.Size(41, 12);
            this.label29_1.TabIndex = 4;
            this.label29_1.Text = "label1";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(50, 84);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(41, 12);
            this.label30.TabIndex = 3;
            this.label30.Text = "- 10 -";
            // 
            // pictureBox29
            // 
            this.pictureBox29.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox29.Location = new System.Drawing.Point(100, 31);
            this.pictureBox29.Name = "pictureBox29";
            this.pictureBox29.Size = new System.Drawing.Size(32, 32);
            this.pictureBox29.TabIndex = 2;
            this.pictureBox29.TabStop = false;
            this.pictureBox29.Tag = "2";
            this.pictureBox29.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox30
            // 
            this.pictureBox30.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox30.Location = new System.Drawing.Point(9, 31);
            this.pictureBox30.Name = "pictureBox30";
            this.pictureBox30.Size = new System.Drawing.Size(32, 32);
            this.pictureBox30.TabIndex = 1;
            this.pictureBox30.TabStop = false;
            this.pictureBox30.Tag = "1";
            this.pictureBox30.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox31
            // 
            this.pictureBox31.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.pictureBox31.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox31.Image")));
            this.pictureBox31.Location = new System.Drawing.Point(45, 22);
            this.pictureBox31.Name = "pictureBox31";
            this.pictureBox31.Size = new System.Drawing.Size(50, 50);
            this.pictureBox31.TabIndex = 0;
            this.pictureBox31.TabStop = false;
            this.pictureBox31.Tag = "0";
            // 
            // Desk_11
            // 
            this.Desk_11.BackColor = System.Drawing.Color.Transparent;
            this.Desk_11.Controls.Add(this.label31_2);
            this.Desk_11.Controls.Add(this.label32_1);
            this.Desk_11.Controls.Add(this.label33);
            this.Desk_11.Controls.Add(this.pictureBox32);
            this.Desk_11.Controls.Add(this.pictureBox33);
            this.Desk_11.Controls.Add(this.pictureBox34);
            this.Desk_11.Location = new System.Drawing.Point(149, 321);
            this.Desk_11.Name = "Desk_11";
            this.Desk_11.Size = new System.Drawing.Size(140, 100);
            this.Desk_11.TabIndex = 11;
            this.Desk_11.Tag = "11";
            // 
            // label31_2
            // 
            this.label31_2.AutoSize = true;
            this.label31_2.Location = new System.Drawing.Point(94, 76);
            this.label31_2.Name = "label31_2";
            this.label31_2.Size = new System.Drawing.Size(41, 12);
            this.label31_2.TabIndex = 5;
            this.label31_2.Text = "label2";
            // 
            // label32_1
            // 
            this.label32_1.AutoSize = true;
            this.label32_1.Location = new System.Drawing.Point(7, 6);
            this.label32_1.Name = "label32_1";
            this.label32_1.Size = new System.Drawing.Size(41, 12);
            this.label32_1.TabIndex = 4;
            this.label32_1.Text = "label1";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(50, 84);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(41, 12);
            this.label33.TabIndex = 3;
            this.label33.Text = "- 11 -";
            // 
            // pictureBox32
            // 
            this.pictureBox32.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox32.Location = new System.Drawing.Point(100, 31);
            this.pictureBox32.Name = "pictureBox32";
            this.pictureBox32.Size = new System.Drawing.Size(32, 32);
            this.pictureBox32.TabIndex = 2;
            this.pictureBox32.TabStop = false;
            this.pictureBox32.Tag = "2";
            this.pictureBox32.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox33
            // 
            this.pictureBox33.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox33.Location = new System.Drawing.Point(9, 31);
            this.pictureBox33.Name = "pictureBox33";
            this.pictureBox33.Size = new System.Drawing.Size(32, 32);
            this.pictureBox33.TabIndex = 1;
            this.pictureBox33.TabStop = false;
            this.pictureBox33.Tag = "1";
            this.pictureBox33.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox34
            // 
            this.pictureBox34.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.pictureBox34.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox34.Image")));
            this.pictureBox34.Location = new System.Drawing.Point(45, 22);
            this.pictureBox34.Name = "pictureBox34";
            this.pictureBox34.Size = new System.Drawing.Size(50, 50);
            this.pictureBox34.TabIndex = 0;
            this.pictureBox34.TabStop = false;
            this.pictureBox34.Tag = "0";
            // 
            // Desk_12
            // 
            this.Desk_12.BackColor = System.Drawing.Color.Transparent;
            this.Desk_12.Controls.Add(this.label34_2);
            this.Desk_12.Controls.Add(this.label35_1);
            this.Desk_12.Controls.Add(this.label36);
            this.Desk_12.Controls.Add(this.pictureBox35);
            this.Desk_12.Controls.Add(this.pictureBox36);
            this.Desk_12.Controls.Add(this.pictureBox37);
            this.Desk_12.Location = new System.Drawing.Point(295, 321);
            this.Desk_12.Name = "Desk_12";
            this.Desk_12.Size = new System.Drawing.Size(140, 100);
            this.Desk_12.TabIndex = 12;
            this.Desk_12.Tag = "12";
            // 
            // label34_2
            // 
            this.label34_2.AutoSize = true;
            this.label34_2.Location = new System.Drawing.Point(94, 76);
            this.label34_2.Name = "label34_2";
            this.label34_2.Size = new System.Drawing.Size(41, 12);
            this.label34_2.TabIndex = 5;
            this.label34_2.Text = "label2";
            // 
            // label35_1
            // 
            this.label35_1.AutoSize = true;
            this.label35_1.Location = new System.Drawing.Point(7, 6);
            this.label35_1.Name = "label35_1";
            this.label35_1.Size = new System.Drawing.Size(41, 12);
            this.label35_1.TabIndex = 4;
            this.label35_1.Text = "label1";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(52, 84);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(41, 12);
            this.label36.TabIndex = 3;
            this.label36.Text = "- 12 -";
            // 
            // pictureBox35
            // 
            this.pictureBox35.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox35.Location = new System.Drawing.Point(100, 31);
            this.pictureBox35.Name = "pictureBox35";
            this.pictureBox35.Size = new System.Drawing.Size(32, 32);
            this.pictureBox35.TabIndex = 2;
            this.pictureBox35.TabStop = false;
            this.pictureBox35.Tag = "2";
            this.pictureBox35.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox36
            // 
            this.pictureBox36.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox36.Location = new System.Drawing.Point(9, 31);
            this.pictureBox36.Name = "pictureBox36";
            this.pictureBox36.Size = new System.Drawing.Size(32, 32);
            this.pictureBox36.TabIndex = 1;
            this.pictureBox36.TabStop = false;
            this.pictureBox36.Tag = "1";
            this.pictureBox36.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox37
            // 
            this.pictureBox37.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.pictureBox37.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox37.Image")));
            this.pictureBox37.Location = new System.Drawing.Point(45, 22);
            this.pictureBox37.Name = "pictureBox37";
            this.pictureBox37.Size = new System.Drawing.Size(50, 50);
            this.pictureBox37.TabIndex = 0;
            this.pictureBox37.TabStop = false;
            this.pictureBox37.Tag = "0";
            // 
            // Desk_13
            // 
            this.Desk_13.BackColor = System.Drawing.Color.Transparent;
            this.Desk_13.Controls.Add(this.label37_2);
            this.Desk_13.Controls.Add(this.label38_1);
            this.Desk_13.Controls.Add(this.label39);
            this.Desk_13.Controls.Add(this.pictureBox38);
            this.Desk_13.Controls.Add(this.pictureBox39);
            this.Desk_13.Controls.Add(this.pictureBox40);
            this.Desk_13.Location = new System.Drawing.Point(3, 427);
            this.Desk_13.Name = "Desk_13";
            this.Desk_13.Size = new System.Drawing.Size(140, 100);
            this.Desk_13.TabIndex = 13;
            this.Desk_13.Tag = "13";
            // 
            // label37_2
            // 
            this.label37_2.AutoSize = true;
            this.label37_2.Location = new System.Drawing.Point(94, 76);
            this.label37_2.Name = "label37_2";
            this.label37_2.Size = new System.Drawing.Size(41, 12);
            this.label37_2.TabIndex = 5;
            this.label37_2.Text = "label2";
            // 
            // label38_1
            // 
            this.label38_1.AutoSize = true;
            this.label38_1.Location = new System.Drawing.Point(7, 6);
            this.label38_1.Name = "label38_1";
            this.label38_1.Size = new System.Drawing.Size(41, 12);
            this.label38_1.TabIndex = 4;
            this.label38_1.Text = "label1";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(50, 84);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(41, 12);
            this.label39.TabIndex = 3;
            this.label39.Text = "- 13 -";
            // 
            // pictureBox38
            // 
            this.pictureBox38.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox38.Location = new System.Drawing.Point(100, 31);
            this.pictureBox38.Name = "pictureBox38";
            this.pictureBox38.Size = new System.Drawing.Size(32, 32);
            this.pictureBox38.TabIndex = 2;
            this.pictureBox38.TabStop = false;
            this.pictureBox38.Tag = "2";
            this.pictureBox38.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox39
            // 
            this.pictureBox39.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox39.Location = new System.Drawing.Point(9, 31);
            this.pictureBox39.Name = "pictureBox39";
            this.pictureBox39.Size = new System.Drawing.Size(32, 32);
            this.pictureBox39.TabIndex = 1;
            this.pictureBox39.TabStop = false;
            this.pictureBox39.Tag = "1";
            this.pictureBox39.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox40
            // 
            this.pictureBox40.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.pictureBox40.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox40.Image")));
            this.pictureBox40.Location = new System.Drawing.Point(45, 22);
            this.pictureBox40.Name = "pictureBox40";
            this.pictureBox40.Size = new System.Drawing.Size(50, 50);
            this.pictureBox40.TabIndex = 0;
            this.pictureBox40.TabStop = false;
            this.pictureBox40.Tag = "0";
            // 
            // Desk_14
            // 
            this.Desk_14.BackColor = System.Drawing.Color.Transparent;
            this.Desk_14.Controls.Add(this.label40_2);
            this.Desk_14.Controls.Add(this.label41_1);
            this.Desk_14.Controls.Add(this.label42);
            this.Desk_14.Controls.Add(this.pictureBox41);
            this.Desk_14.Controls.Add(this.pictureBox42);
            this.Desk_14.Controls.Add(this.pictureBox43);
            this.Desk_14.Location = new System.Drawing.Point(149, 427);
            this.Desk_14.Name = "Desk_14";
            this.Desk_14.Size = new System.Drawing.Size(140, 100);
            this.Desk_14.TabIndex = 14;
            this.Desk_14.Tag = "14";
            // 
            // label40_2
            // 
            this.label40_2.AutoSize = true;
            this.label40_2.Location = new System.Drawing.Point(94, 76);
            this.label40_2.Name = "label40_2";
            this.label40_2.Size = new System.Drawing.Size(41, 12);
            this.label40_2.TabIndex = 5;
            this.label40_2.Text = "label2";
            // 
            // label41_1
            // 
            this.label41_1.AutoSize = true;
            this.label41_1.Location = new System.Drawing.Point(7, 6);
            this.label41_1.Name = "label41_1";
            this.label41_1.Size = new System.Drawing.Size(41, 12);
            this.label41_1.TabIndex = 4;
            this.label41_1.Text = "label1";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(50, 84);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(41, 12);
            this.label42.TabIndex = 3;
            this.label42.Text = "- 14 -";
            // 
            // pictureBox41
            // 
            this.pictureBox41.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox41.Location = new System.Drawing.Point(100, 31);
            this.pictureBox41.Name = "pictureBox41";
            this.pictureBox41.Size = new System.Drawing.Size(32, 32);
            this.pictureBox41.TabIndex = 2;
            this.pictureBox41.TabStop = false;
            this.pictureBox41.Tag = "2";
            this.pictureBox41.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox42
            // 
            this.pictureBox42.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox42.Location = new System.Drawing.Point(9, 31);
            this.pictureBox42.Name = "pictureBox42";
            this.pictureBox42.Size = new System.Drawing.Size(32, 32);
            this.pictureBox42.TabIndex = 1;
            this.pictureBox42.TabStop = false;
            this.pictureBox42.Tag = "1";
            this.pictureBox42.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox43
            // 
            this.pictureBox43.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.pictureBox43.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox43.Image")));
            this.pictureBox43.Location = new System.Drawing.Point(45, 22);
            this.pictureBox43.Name = "pictureBox43";
            this.pictureBox43.Size = new System.Drawing.Size(50, 50);
            this.pictureBox43.TabIndex = 0;
            this.pictureBox43.TabStop = false;
            this.pictureBox43.Tag = "0";
            // 
            // Desk_15
            // 
            this.Desk_15.BackColor = System.Drawing.Color.Transparent;
            this.Desk_15.Controls.Add(this.label43_2);
            this.Desk_15.Controls.Add(this.label44_1);
            this.Desk_15.Controls.Add(this.label45);
            this.Desk_15.Controls.Add(this.pictureBox44);
            this.Desk_15.Controls.Add(this.pictureBox45);
            this.Desk_15.Controls.Add(this.pictureBox46);
            this.Desk_15.Location = new System.Drawing.Point(295, 427);
            this.Desk_15.Name = "Desk_15";
            this.Desk_15.Size = new System.Drawing.Size(140, 100);
            this.Desk_15.TabIndex = 15;
            this.Desk_15.Tag = "15";
            // 
            // label43_2
            // 
            this.label43_2.AutoSize = true;
            this.label43_2.Location = new System.Drawing.Point(94, 76);
            this.label43_2.Name = "label43_2";
            this.label43_2.Size = new System.Drawing.Size(41, 12);
            this.label43_2.TabIndex = 5;
            this.label43_2.Text = "label2";
            // 
            // label44_1
            // 
            this.label44_1.AutoSize = true;
            this.label44_1.Location = new System.Drawing.Point(7, 6);
            this.label44_1.Name = "label44_1";
            this.label44_1.Size = new System.Drawing.Size(41, 12);
            this.label44_1.TabIndex = 4;
            this.label44_1.Text = "label1";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(51, 84);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(41, 12);
            this.label45.TabIndex = 3;
            this.label45.Text = "- 15 -";
            // 
            // pictureBox44
            // 
            this.pictureBox44.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox44.Location = new System.Drawing.Point(100, 31);
            this.pictureBox44.Name = "pictureBox44";
            this.pictureBox44.Size = new System.Drawing.Size(32, 32);
            this.pictureBox44.TabIndex = 2;
            this.pictureBox44.TabStop = false;
            this.pictureBox44.Tag = "2";
            this.pictureBox44.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox45
            // 
            this.pictureBox45.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox45.Location = new System.Drawing.Point(9, 31);
            this.pictureBox45.Name = "pictureBox45";
            this.pictureBox45.Size = new System.Drawing.Size(32, 32);
            this.pictureBox45.TabIndex = 1;
            this.pictureBox45.TabStop = false;
            this.pictureBox45.Tag = "1";
            this.pictureBox45.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox46
            // 
            this.pictureBox46.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.pictureBox46.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox46.Image")));
            this.pictureBox46.Location = new System.Drawing.Point(45, 22);
            this.pictureBox46.Name = "pictureBox46";
            this.pictureBox46.Size = new System.Drawing.Size(50, 50);
            this.pictureBox46.TabIndex = 0;
            this.pictureBox46.TabStop = false;
            this.pictureBox46.Tag = "0";
            // 
            // Desk_16
            // 
            this.Desk_16.BackColor = System.Drawing.Color.Transparent;
            this.Desk_16.Controls.Add(this.label46_2);
            this.Desk_16.Controls.Add(this.label47_1);
            this.Desk_16.Controls.Add(this.label48);
            this.Desk_16.Controls.Add(this.pictureBox47);
            this.Desk_16.Controls.Add(this.pictureBox48);
            this.Desk_16.Controls.Add(this.pictureBox49);
            this.Desk_16.Location = new System.Drawing.Point(3, 533);
            this.Desk_16.Name = "Desk_16";
            this.Desk_16.Size = new System.Drawing.Size(140, 100);
            this.Desk_16.TabIndex = 16;
            this.Desk_16.Tag = "16";
            // 
            // label46_2
            // 
            this.label46_2.AutoSize = true;
            this.label46_2.Location = new System.Drawing.Point(94, 76);
            this.label46_2.Name = "label46_2";
            this.label46_2.Size = new System.Drawing.Size(41, 12);
            this.label46_2.TabIndex = 5;
            this.label46_2.Text = "label2";
            // 
            // label47_1
            // 
            this.label47_1.AutoSize = true;
            this.label47_1.Location = new System.Drawing.Point(7, 6);
            this.label47_1.Name = "label47_1";
            this.label47_1.Size = new System.Drawing.Size(41, 12);
            this.label47_1.TabIndex = 4;
            this.label47_1.Text = "label1";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(50, 84);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(41, 12);
            this.label48.TabIndex = 3;
            this.label48.Text = "- 16 -";
            // 
            // pictureBox47
            // 
            this.pictureBox47.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox47.Location = new System.Drawing.Point(100, 31);
            this.pictureBox47.Name = "pictureBox47";
            this.pictureBox47.Size = new System.Drawing.Size(32, 32);
            this.pictureBox47.TabIndex = 2;
            this.pictureBox47.TabStop = false;
            this.pictureBox47.Tag = "2";
            this.pictureBox47.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox48
            // 
            this.pictureBox48.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox48.Location = new System.Drawing.Point(9, 31);
            this.pictureBox48.Name = "pictureBox48";
            this.pictureBox48.Size = new System.Drawing.Size(32, 32);
            this.pictureBox48.TabIndex = 1;
            this.pictureBox48.TabStop = false;
            this.pictureBox48.Tag = "1";
            this.pictureBox48.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox49
            // 
            this.pictureBox49.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.pictureBox49.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox49.Image")));
            this.pictureBox49.Location = new System.Drawing.Point(45, 22);
            this.pictureBox49.Name = "pictureBox49";
            this.pictureBox49.Size = new System.Drawing.Size(50, 50);
            this.pictureBox49.TabIndex = 0;
            this.pictureBox49.TabStop = false;
            this.pictureBox49.Tag = "0";
            // 
            // Desk_17
            // 
            this.Desk_17.BackColor = System.Drawing.Color.Transparent;
            this.Desk_17.Controls.Add(this.label49_2);
            this.Desk_17.Controls.Add(this.label50_1);
            this.Desk_17.Controls.Add(this.label51);
            this.Desk_17.Controls.Add(this.pictureBox50);
            this.Desk_17.Controls.Add(this.pictureBox51);
            this.Desk_17.Controls.Add(this.pictureBox52);
            this.Desk_17.Location = new System.Drawing.Point(149, 533);
            this.Desk_17.Name = "Desk_17";
            this.Desk_17.Size = new System.Drawing.Size(140, 100);
            this.Desk_17.TabIndex = 17;
            this.Desk_17.Tag = "17";
            // 
            // label49_2
            // 
            this.label49_2.AutoSize = true;
            this.label49_2.Location = new System.Drawing.Point(94, 76);
            this.label49_2.Name = "label49_2";
            this.label49_2.Size = new System.Drawing.Size(41, 12);
            this.label49_2.TabIndex = 5;
            this.label49_2.Text = "label2";
            // 
            // label50_1
            // 
            this.label50_1.AutoSize = true;
            this.label50_1.Location = new System.Drawing.Point(7, 6);
            this.label50_1.Name = "label50_1";
            this.label50_1.Size = new System.Drawing.Size(41, 12);
            this.label50_1.TabIndex = 4;
            this.label50_1.Text = "label1";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(50, 84);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(41, 12);
            this.label51.TabIndex = 3;
            this.label51.Text = "- 17 -";
            // 
            // pictureBox50
            // 
            this.pictureBox50.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox50.Location = new System.Drawing.Point(100, 31);
            this.pictureBox50.Name = "pictureBox50";
            this.pictureBox50.Size = new System.Drawing.Size(32, 32);
            this.pictureBox50.TabIndex = 2;
            this.pictureBox50.TabStop = false;
            this.pictureBox50.Tag = "2";
            this.pictureBox50.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox51
            // 
            this.pictureBox51.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox51.Location = new System.Drawing.Point(9, 31);
            this.pictureBox51.Name = "pictureBox51";
            this.pictureBox51.Size = new System.Drawing.Size(32, 32);
            this.pictureBox51.TabIndex = 1;
            this.pictureBox51.TabStop = false;
            this.pictureBox51.Tag = "1";
            this.pictureBox51.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox52
            // 
            this.pictureBox52.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.pictureBox52.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox52.Image")));
            this.pictureBox52.Location = new System.Drawing.Point(45, 22);
            this.pictureBox52.Name = "pictureBox52";
            this.pictureBox52.Size = new System.Drawing.Size(50, 50);
            this.pictureBox52.TabIndex = 0;
            this.pictureBox52.TabStop = false;
            this.pictureBox52.Tag = "0";
            // 
            // Desk_18
            // 
            this.Desk_18.BackColor = System.Drawing.Color.Transparent;
            this.Desk_18.Controls.Add(this.label52_2);
            this.Desk_18.Controls.Add(this.label53_1);
            this.Desk_18.Controls.Add(this.label54);
            this.Desk_18.Controls.Add(this.pictureBox53);
            this.Desk_18.Controls.Add(this.pictureBox54);
            this.Desk_18.Controls.Add(this.pictureBox55);
            this.Desk_18.Location = new System.Drawing.Point(295, 533);
            this.Desk_18.Name = "Desk_18";
            this.Desk_18.Size = new System.Drawing.Size(140, 100);
            this.Desk_18.TabIndex = 18;
            this.Desk_18.Tag = "18";
            // 
            // label52_2
            // 
            this.label52_2.AutoSize = true;
            this.label52_2.Location = new System.Drawing.Point(94, 76);
            this.label52_2.Name = "label52_2";
            this.label52_2.Size = new System.Drawing.Size(41, 12);
            this.label52_2.TabIndex = 5;
            this.label52_2.Text = "label2";
            // 
            // label53_1
            // 
            this.label53_1.AutoSize = true;
            this.label53_1.Location = new System.Drawing.Point(7, 6);
            this.label53_1.Name = "label53_1";
            this.label53_1.Size = new System.Drawing.Size(41, 12);
            this.label53_1.TabIndex = 4;
            this.label53_1.Text = "label1";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(51, 84);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(41, 12);
            this.label54.TabIndex = 3;
            this.label54.Text = "- 18 -";
            // 
            // pictureBox53
            // 
            this.pictureBox53.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox53.Location = new System.Drawing.Point(100, 31);
            this.pictureBox53.Name = "pictureBox53";
            this.pictureBox53.Size = new System.Drawing.Size(32, 32);
            this.pictureBox53.TabIndex = 2;
            this.pictureBox53.TabStop = false;
            this.pictureBox53.Tag = "2";
            this.pictureBox53.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox54
            // 
            this.pictureBox54.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox54.Location = new System.Drawing.Point(9, 31);
            this.pictureBox54.Name = "pictureBox54";
            this.pictureBox54.Size = new System.Drawing.Size(32, 32);
            this.pictureBox54.TabIndex = 1;
            this.pictureBox54.TabStop = false;
            this.pictureBox54.Tag = "1";
            this.pictureBox54.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox55
            // 
            this.pictureBox55.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.pictureBox55.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox55.Image")));
            this.pictureBox55.Location = new System.Drawing.Point(45, 22);
            this.pictureBox55.Name = "pictureBox55";
            this.pictureBox55.Size = new System.Drawing.Size(50, 50);
            this.pictureBox55.TabIndex = 0;
            this.pictureBox55.TabStop = false;
            this.pictureBox55.Tag = "0";
            // 
            // Desk_19
            // 
            this.Desk_19.BackColor = System.Drawing.Color.Transparent;
            this.Desk_19.Controls.Add(this.label55_2);
            this.Desk_19.Controls.Add(this.label56_1);
            this.Desk_19.Controls.Add(this.label57);
            this.Desk_19.Controls.Add(this.pictureBox56);
            this.Desk_19.Controls.Add(this.pictureBox57);
            this.Desk_19.Controls.Add(this.pictureBox58);
            this.Desk_19.Location = new System.Drawing.Point(3, 639);
            this.Desk_19.Name = "Desk_19";
            this.Desk_19.Size = new System.Drawing.Size(140, 100);
            this.Desk_19.TabIndex = 19;
            this.Desk_19.Tag = "19";
            // 
            // label55_2
            // 
            this.label55_2.AutoSize = true;
            this.label55_2.Location = new System.Drawing.Point(94, 76);
            this.label55_2.Name = "label55_2";
            this.label55_2.Size = new System.Drawing.Size(41, 12);
            this.label55_2.TabIndex = 5;
            this.label55_2.Text = "label2";
            // 
            // label56_1
            // 
            this.label56_1.AutoSize = true;
            this.label56_1.Location = new System.Drawing.Point(7, 6);
            this.label56_1.Name = "label56_1";
            this.label56_1.Size = new System.Drawing.Size(41, 12);
            this.label56_1.TabIndex = 4;
            this.label56_1.Text = "label1";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(50, 84);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(41, 12);
            this.label57.TabIndex = 3;
            this.label57.Text = "- 19 -";
            // 
            // pictureBox56
            // 
            this.pictureBox56.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox56.Location = new System.Drawing.Point(100, 31);
            this.pictureBox56.Name = "pictureBox56";
            this.pictureBox56.Size = new System.Drawing.Size(32, 32);
            this.pictureBox56.TabIndex = 2;
            this.pictureBox56.TabStop = false;
            this.pictureBox56.Tag = "2";
            this.pictureBox56.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox57
            // 
            this.pictureBox57.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox57.Location = new System.Drawing.Point(9, 31);
            this.pictureBox57.Name = "pictureBox57";
            this.pictureBox57.Size = new System.Drawing.Size(32, 32);
            this.pictureBox57.TabIndex = 1;
            this.pictureBox57.TabStop = false;
            this.pictureBox57.Tag = "1";
            this.pictureBox57.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox58
            // 
            this.pictureBox58.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.pictureBox58.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox58.Image")));
            this.pictureBox58.Location = new System.Drawing.Point(45, 22);
            this.pictureBox58.Name = "pictureBox58";
            this.pictureBox58.Size = new System.Drawing.Size(50, 50);
            this.pictureBox58.TabIndex = 0;
            this.pictureBox58.TabStop = false;
            this.pictureBox58.Tag = "0";
            // 
            // Desk_20
            // 
            this.Desk_20.BackColor = System.Drawing.Color.Transparent;
            this.Desk_20.Controls.Add(this.label58_2);
            this.Desk_20.Controls.Add(this.label59_1);
            this.Desk_20.Controls.Add(this.label60);
            this.Desk_20.Controls.Add(this.pictureBox59);
            this.Desk_20.Controls.Add(this.pictureBox60);
            this.Desk_20.Controls.Add(this.pictureBox61);
            this.Desk_20.Location = new System.Drawing.Point(149, 639);
            this.Desk_20.Name = "Desk_20";
            this.Desk_20.Size = new System.Drawing.Size(140, 100);
            this.Desk_20.TabIndex = 20;
            this.Desk_20.Tag = "20";
            // 
            // label58_2
            // 
            this.label58_2.AutoSize = true;
            this.label58_2.Location = new System.Drawing.Point(94, 76);
            this.label58_2.Name = "label58_2";
            this.label58_2.Size = new System.Drawing.Size(41, 12);
            this.label58_2.TabIndex = 5;
            this.label58_2.Text = "label2";
            // 
            // label59_1
            // 
            this.label59_1.AutoSize = true;
            this.label59_1.Location = new System.Drawing.Point(7, 6);
            this.label59_1.Name = "label59_1";
            this.label59_1.Size = new System.Drawing.Size(41, 12);
            this.label59_1.TabIndex = 4;
            this.label59_1.Text = "label1";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(50, 84);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(41, 12);
            this.label60.TabIndex = 3;
            this.label60.Text = "- 20 -";
            // 
            // pictureBox59
            // 
            this.pictureBox59.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox59.Location = new System.Drawing.Point(100, 31);
            this.pictureBox59.Name = "pictureBox59";
            this.pictureBox59.Size = new System.Drawing.Size(32, 32);
            this.pictureBox59.TabIndex = 2;
            this.pictureBox59.TabStop = false;
            this.pictureBox59.Tag = "2";
            this.pictureBox59.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox60
            // 
            this.pictureBox60.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox60.Location = new System.Drawing.Point(9, 31);
            this.pictureBox60.Name = "pictureBox60";
            this.pictureBox60.Size = new System.Drawing.Size(32, 32);
            this.pictureBox60.TabIndex = 1;
            this.pictureBox60.TabStop = false;
            this.pictureBox60.Tag = "1";
            this.pictureBox60.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox61
            // 
            this.pictureBox61.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.pictureBox61.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox61.Image")));
            this.pictureBox61.Location = new System.Drawing.Point(45, 22);
            this.pictureBox61.Name = "pictureBox61";
            this.pictureBox61.Size = new System.Drawing.Size(50, 50);
            this.pictureBox61.TabIndex = 0;
            this.pictureBox61.TabStop = false;
            this.pictureBox61.Tag = "0";
            // 
            // udpSocket1
            // 
            this.udpSocket1.Active = false;
            this.udpSocket1.LocalHost = "127.0.0.1";
            this.udpSocket1.LocalPort = 11000;
            this.udpSocket1.DataArrival += new GobangClass.UDPSocket.DataArrivalEventHandler(this.udpSocket1_DataArrival);
            // 
            // pictureBox63
            // 
            this.pictureBox63.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox63.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox63.BackgroundImage")));
            this.pictureBox63.Dock = System.Windows.Forms.DockStyle.Left;
            this.pictureBox63.Location = new System.Drawing.Point(0, 0);
            this.pictureBox63.Name = "pictureBox63";
            this.pictureBox63.Size = new System.Drawing.Size(651, 69);
            this.pictureBox63.TabIndex = 0;
            this.pictureBox63.TabStop = false;
            // 
            // panel_Cover
            // 
            this.panel_Cover.BackColor = System.Drawing.Color.Transparent;
            this.panel_Cover.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel_Cover.BackgroundImage")));
            this.panel_Cover.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel_Cover.Controls.Add(this.pictureBox63);
            this.panel_Cover.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_Cover.Location = new System.Drawing.Point(3, 27);
            this.panel_Cover.Name = "panel_Cover";
            this.panel_Cover.Size = new System.Drawing.Size(921, 69);
            this.panel_Cover.TabIndex = 3;
            // 
            // Frm_Hall
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(927, 585);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel_OpposeTit);
            this.Controls.Add(this.panel_RA);
            this.Controls.Add(this.panel_Public);
            this.Controls.Add(this.panel_LAmong);
            this.Controls.Add(this.panel_Tree);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel_BorderT);
            this.Controls.Add(this.panel_Cover);
            this.Controls.Add(this.panel_BorderR);
            this.Controls.Add(this.panel_BorderL);
            this.Controls.Add(this.panel_Title);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Frm_Hall";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Frm_Hall";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Shown += new System.EventHandler(this.Frm_Hall_Shown);
            this.panel_Title.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Image_Max)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Image_Close)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Image_Min)).EndInit();
            this.panel_Tree.ResumeLayout(false);
            this.panel_LAmong.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_LA)).EndInit();
            this.panel_Public.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel_DialogB.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Hair)).EndInit();
            this.panel_PerTit.ResumeLayout(false);
            this.panel_PerTit.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox65)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox64)).EndInit();
            this.panel_RA.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Back)).EndInit();
            this.flowPanel_Oppose.ResumeLayout(false);
            this.Desk_01.ResumeLayout(false);
            this.Desk_01.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.Desk_02.ResumeLayout(false);
            this.Desk_02.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            this.Desk_03.ResumeLayout(false);
            this.Desk_03.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            this.Desk_04.ResumeLayout(false);
            this.Desk_04.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            this.Desk_05.ResumeLayout(false);
            this.Desk_05.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).EndInit();
            this.Desk_06.ResumeLayout(false);
            this.Desk_06.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).EndInit();
            this.Desk_07.ResumeLayout(false);
            this.Desk_07.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox22)).EndInit();
            this.Desk_08.ResumeLayout(false);
            this.Desk_08.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox25)).EndInit();
            this.Desk_09.ResumeLayout(false);
            this.Desk_09.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox26)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox27)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox28)).EndInit();
            this.Desk_10.ResumeLayout(false);
            this.Desk_10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox29)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox30)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox31)).EndInit();
            this.Desk_11.ResumeLayout(false);
            this.Desk_11.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox32)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox33)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox34)).EndInit();
            this.Desk_12.ResumeLayout(false);
            this.Desk_12.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox35)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox36)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox37)).EndInit();
            this.Desk_13.ResumeLayout(false);
            this.Desk_13.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox38)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox39)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox40)).EndInit();
            this.Desk_14.ResumeLayout(false);
            this.Desk_14.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox41)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox42)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox43)).EndInit();
            this.Desk_15.ResumeLayout(false);
            this.Desk_15.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox44)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox45)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox46)).EndInit();
            this.Desk_16.ResumeLayout(false);
            this.Desk_16.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox47)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox48)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox49)).EndInit();
            this.Desk_17.ResumeLayout(false);
            this.Desk_17.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox50)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox51)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox52)).EndInit();
            this.Desk_18.ResumeLayout(false);
            this.Desk_18.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox53)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox54)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox55)).EndInit();
            this.Desk_19.ResumeLayout(false);
            this.Desk_19.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox56)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox57)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox58)).EndInit();
            this.Desk_20.ResumeLayout(false);
            this.Desk_20.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox59)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox60)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox61)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox63)).EndInit();
            this.panel_Cover.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private GobangClass.UDPSocket udpSocket1;
        private System.Windows.Forms.Panel panel_Title;
        private System.Windows.Forms.PictureBox Image_Max;
        private System.Windows.Forms.PictureBox Image_Close;
        private System.Windows.Forms.PictureBox Image_Min;
        private System.Windows.Forms.Panel panel_BorderL;
        private System.Windows.Forms.Panel panel_BorderR;
        private System.Windows.Forms.Panel panel_BorderT;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel_Tree;
        private System.Windows.Forms.Panel panel_TreeT;
        private System.Windows.Forms.TreeView treeView_Area;
        private System.Windows.Forms.Panel panel_LAmong;
        private System.Windows.Forms.PictureBox pictureBox_LA;
        private System.Windows.Forms.Panel panel_Public;
        private System.Windows.Forms.Panel panel_PerTit;
        private System.Windows.Forms.Panel panel_DialogTit;
        private System.Windows.Forms.ListView listView_user;
        private System.Windows.Forms.Panel panel_DialogB;
        private System.Windows.Forms.PictureBox pictureBox_Hair;
        private System.Windows.Forms.ComboBox comboBox_Hair;
        private System.Windows.Forms.Panel panel_RA;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel_OpposeTit;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.FlowLayoutPanel flowPanel_Oppose;
        private System.Windows.Forms.Panel Desk_01;
        private System.Windows.Forms.Label label1_2;
        private System.Windows.Forms.Label label2_1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Panel Desk_02;
        private System.Windows.Forms.Label label4_2;
        private System.Windows.Forms.Label label5_1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.Panel Desk_03;
        private System.Windows.Forms.Label label7_2;
        private System.Windows.Forms.Label label8_1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.Panel Desk_04;
        private System.Windows.Forms.Label label10_2;
        private System.Windows.Forms.Label label11_1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.Panel Desk_05;
        private System.Windows.Forms.Label label16_2;
        private System.Windows.Forms.Label label17_1;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.PictureBox pictureBox17;
        private System.Windows.Forms.PictureBox pictureBox18;
        private System.Windows.Forms.PictureBox pictureBox19;
        private System.Windows.Forms.Panel Desk_06;
        private System.Windows.Forms.Label label13_2;
        private System.Windows.Forms.Label label14_1;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.PictureBox pictureBox14;
        private System.Windows.Forms.PictureBox pictureBox15;
        private System.Windows.Forms.PictureBox pictureBox16;
        private System.Windows.Forms.Panel Desk_07;
        private System.Windows.Forms.Label label19_2;
        private System.Windows.Forms.Label label20_1;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.PictureBox pictureBox20;
        private System.Windows.Forms.PictureBox pictureBox21;
        private System.Windows.Forms.PictureBox pictureBox22;
        private System.Windows.Forms.Panel Desk_08;
        private System.Windows.Forms.Label label22_2;
        private System.Windows.Forms.Label label23_1;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.PictureBox pictureBox23;
        private System.Windows.Forms.PictureBox pictureBox24;
        private System.Windows.Forms.PictureBox pictureBox25;
        private System.Windows.Forms.Panel Desk_09;
        private System.Windows.Forms.Label label25_2;
        private System.Windows.Forms.Label label26_1;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.PictureBox pictureBox26;
        private System.Windows.Forms.PictureBox pictureBox27;
        private System.Windows.Forms.PictureBox pictureBox28;
        private System.Windows.Forms.Panel Desk_10;
        private System.Windows.Forms.Label label28_2;
        private System.Windows.Forms.Label label29_1;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.PictureBox pictureBox29;
        private System.Windows.Forms.PictureBox pictureBox30;
        private System.Windows.Forms.PictureBox pictureBox31;
        private System.Windows.Forms.Panel Desk_11;
        private System.Windows.Forms.Label label31_2;
        private System.Windows.Forms.Label label32_1;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.PictureBox pictureBox32;
        private System.Windows.Forms.PictureBox pictureBox33;
        private System.Windows.Forms.PictureBox pictureBox34;
        private System.Windows.Forms.Panel Desk_12;
        private System.Windows.Forms.Label label34_2;
        private System.Windows.Forms.Label label35_1;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.PictureBox pictureBox35;
        private System.Windows.Forms.PictureBox pictureBox36;
        private System.Windows.Forms.PictureBox pictureBox37;
        private System.Windows.Forms.Panel Desk_13;
        private System.Windows.Forms.Label label37_2;
        private System.Windows.Forms.Label label38_1;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.PictureBox pictureBox38;
        private System.Windows.Forms.PictureBox pictureBox39;
        private System.Windows.Forms.PictureBox pictureBox40;
        private System.Windows.Forms.Panel Desk_14;
        private System.Windows.Forms.Label label40_2;
        private System.Windows.Forms.Label label41_1;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.PictureBox pictureBox41;
        private System.Windows.Forms.PictureBox pictureBox42;
        private System.Windows.Forms.PictureBox pictureBox43;
        private System.Windows.Forms.Panel Desk_15;
        private System.Windows.Forms.Label label43_2;
        private System.Windows.Forms.Label label44_1;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.PictureBox pictureBox44;
        private System.Windows.Forms.PictureBox pictureBox45;
        private System.Windows.Forms.PictureBox pictureBox46;
        private System.Windows.Forms.Panel Desk_16;
        private System.Windows.Forms.Label label46_2;
        private System.Windows.Forms.Label label47_1;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.PictureBox pictureBox47;
        private System.Windows.Forms.PictureBox pictureBox48;
        private System.Windows.Forms.PictureBox pictureBox49;
        private System.Windows.Forms.Panel Desk_17;
        private System.Windows.Forms.Label label49_2;
        private System.Windows.Forms.Label label50_1;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.PictureBox pictureBox50;
        private System.Windows.Forms.PictureBox pictureBox51;
        private System.Windows.Forms.PictureBox pictureBox52;
        private System.Windows.Forms.Panel Desk_18;
        private System.Windows.Forms.Label label52_2;
        private System.Windows.Forms.Label label53_1;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.PictureBox pictureBox53;
        private System.Windows.Forms.PictureBox pictureBox54;
        private System.Windows.Forms.PictureBox pictureBox55;
        private System.Windows.Forms.Panel Desk_19;
        private System.Windows.Forms.Label label55_2;
        private System.Windows.Forms.Label label56_1;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.PictureBox pictureBox56;
        private System.Windows.Forms.PictureBox pictureBox57;
        private System.Windows.Forms.PictureBox pictureBox58;
        private System.Windows.Forms.Panel Desk_20;
        private System.Windows.Forms.Label label58_2;
        private System.Windows.Forms.Label label59_1;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.PictureBox pictureBox59;
        private System.Windows.Forms.PictureBox pictureBox60;
        private System.Windows.Forms.PictureBox pictureBox61;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ImageList imageList2;
        private System.Windows.Forms.PictureBox pictureBox_Back;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.RichTextBox RTB_Dialog;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox pictureBox65;
        private System.Windows.Forms.PictureBox pictureBox64;
        private System.Windows.Forms.PictureBox pictureBox63;
        private System.Windows.Forms.Panel panel_Cover;
    }
}

